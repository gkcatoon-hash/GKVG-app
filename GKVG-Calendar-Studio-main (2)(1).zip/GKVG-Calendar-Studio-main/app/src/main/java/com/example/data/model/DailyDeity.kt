package com.example.data.model

import java.time.DayOfWeek

data class DailyDeity(
    val dayOfWeek: DayOfWeek,
    val deityName: LocalizedText,
    val title: LocalizedText,
    val specialPooja: LocalizedText,
    val sacredChant: String,
    val auspiciousColor: LocalizedText,
    val flowerOffering: LocalizedText,
    val templeSpotlight: LocalizedText
)
