package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.PanchangData
import com.example.ui.theme.AmritaKalamGreen
import com.example.ui.theme.AuspiciousSaffron
import com.example.ui.theme.GulikaBlue
import com.example.ui.theme.RahuKalamRed
import com.example.ui.theme.SacredGold300
import com.example.ui.theme.SacredGold400
import com.example.ui.theme.SacredGold500
import com.example.ui.theme.SacredGold600
import com.example.ui.theme.SleekCardElevated
import com.example.ui.theme.SleekCardSurface
import com.example.ui.theme.SleekNavyBackground
import com.example.ui.theme.SleekObsidianNav
import com.example.ui.theme.YamaGandamOrange

@Composable
fun PanchangCard(
    panchang: PanchangData,
    language: AppLanguage,
    isExpanded: Boolean,
    onToggleExpanded: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = SleekCardSurface
        ),
        border = BorderStroke(1.dp, SacredGold500.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("panchang_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Sleek Header with Accent Bar & Tracking
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(16.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(SacredGold500)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TODAY'S PANCHANG",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = SacredGold500,
                        letterSpacing = 2.sp
                    )
                }

                // Paksham & Masam Pill Badge
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SleekObsidianNav.copy(alpha = 0.6f),
                    border = BorderStroke(1.dp, SacredGold500.copy(alpha = 0.35f))
                ) {
                    Text(
                        text = "${panchang.masam.get(language)} • ${panchang.paksham.get(language)}",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = SacredGold400,
                        letterSpacing = 0.5.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2x2 Clean Grid matching Sleek Design
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Tithi
                SleekGridItem(
                    label = "TITHI",
                    primaryValue = panchang.tithi.get(language),
                    secondaryValue = "Till ${panchang.tithiEndTime}",
                    modifier = Modifier.weight(1f)
                )

                // Nakshatram
                SleekGridItem(
                    label = "NAKSHATRAM",
                    primaryValue = panchang.nakshatram.get(language),
                    secondaryValue = "Till ${panchang.nakshatramEndTime}",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Sunrise / Sunset
                SleekGridItem(
                    label = "SUNRISE / SUNSET",
                    primaryValue = "${panchang.sunrise} / ${panchang.sunset}",
                    secondaryValue = "Dina Pramanam: 12h 14m",
                    modifier = Modifier.weight(1f)
                )

                // Vara (Day of Week)
                SleekGridItem(
                    label = "VARA (DAY)",
                    primaryValue = panchang.vara.get(language),
                    secondaryValue = panchang.yogam.get(language),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = SacredGold500.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(12.dp))

            // Kalam Timings Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                KalamTimingItem(
                    title = "Rahu Kalam",
                    timing = panchang.rahukalam,
                    color = RahuKalamRed
                )
                KalamTimingItem(
                    title = "Yamagandam",
                    timing = panchang.yamagandam,
                    color = YamaGandamOrange
                )
                KalamTimingItem(
                    title = "Gulika Kalam",
                    timing = panchang.gulikakalam,
                    color = GulikaBlue
                )
            }

            // Expandable Muhurthams
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp)
                ) {
                    HorizontalDivider(color = SacredGold500.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "MUHURTHAM & SHUBHA TIMINGS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SacredGold400,
                        letterSpacing = 1.5.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    DetailLine(label = "అమృత ఘడియలు (Amrita):", value = panchang.amritakalam, color = AmritaKalamGreen)
                    Spacer(modifier = Modifier.height(4.dp))
                    DetailLine(label = "అభిజిత్ ముహూర్తం (Abhijit):", value = panchang.abhijitMuhurtham, color = SacredGold400)
                    Spacer(modifier = Modifier.height(4.dp))
                    DetailLine(label = "దుర్ముహూర్తం (Durmuhurtham):", value = panchang.durmuhurtham, color = RahuKalamRed)
                    Spacer(modifier = Modifier.height(4.dp))
                    DetailLine(label = "వర్జ్యం (Varjyam):", value = panchang.varjyam, color = YamaGandamOrange)
                    Spacer(modifier = Modifier.height(4.dp))
                    DetailLine(label = "కరణం (Karanam):", value = panchang.karanam.get(language), color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Expand / Collapse Toggle Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onToggleExpanded() }
                    .padding(vertical = 4.dp)
                    .testTag("toggle_panchang_details"),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isExpanded) "Show Less" else "More Muhurtham Details",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SacredGold400
                )
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = SacredGold400,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun SleekGridItem(
    label: String,
    primaryValue: String,
    secondaryValue: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White.copy(alpha = 0.5f),
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = primaryValue,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            maxLines = 1
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = secondaryValue,
            fontSize = 11.sp,
            color = SacredGold400.copy(alpha = 0.85f),
            maxLines = 1
        )
    }
}

@Composable
private fun KalamTimingItem(
    title: String,
    timing: String,
    color: Color
) {
    Column(horizontalAlignment = Alignment.Start) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.6f)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = timing,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White
        )
    }
}

@Composable
private fun DetailLine(
    label: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color.White.copy(alpha = 0.7f)
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = color
        )
    }
}

