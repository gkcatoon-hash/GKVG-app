package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Celebration
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.SelfImprovement
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.data.model.AppLanguage

enum class AppNavigationTab(
    val englishTitle: String,
    val teluguTitle: String,
    val hindiTitle: String,
    val tamilTitle: String,
    val kannadaTitle: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    HOME(
        englishTitle = "Home",
        teluguTitle = "హోమ్ (Home)",
        hindiTitle = "होम",
        tamilTitle = "முகப்பு",
        kannadaTitle = "ಮುಖಪುಟ",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home
    ),
    CALENDAR(
        englishTitle = "Calendar",
        teluguTitle = "క్యాలెండర్",
        hindiTitle = "कैलेंडर",
        tamilTitle = "காலண்டர்",
        kannadaTitle = "ಕ್ಯಾಲೆಂಡರ್",
        selectedIcon = Icons.Filled.CalendarMonth,
        unselectedIcon = Icons.Outlined.CalendarMonth
    ),
    FESTIVALS(
        englishTitle = "Festivals",
        teluguTitle = "పండుగలు",
        hindiTitle = "त्योहार",
        tamilTitle = "பண்டிகைகள்",
        kannadaTitle = "ಹಬ್ಬಗಳು",
        selectedIcon = Icons.Filled.Celebration,
        unselectedIcon = Icons.Outlined.Celebration
    ),
    DEVOTION(
        englishTitle = "Devotion",
        teluguTitle = "భక్తి (Devotion)",
        hindiTitle = "भक्ति",
        tamilTitle = "பக்தி",
        kannadaTitle = "ಭಕ್ತಿ",
        selectedIcon = Icons.Filled.SelfImprovement,
        unselectedIcon = Icons.Outlined.SelfImprovement
    ),
    SETTINGS(
        englishTitle = "Settings",
        teluguTitle = "సెట్టింగ్స్",
        hindiTitle = "सेटिंग्स",
        tamilTitle = "அமைப்புகள்",
        kannadaTitle = "ಸೆಟ್ಟಿಂಗ್ಸ್",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings
    );

    fun getLabel(language: AppLanguage): String {
        return when (language) {
            AppLanguage.TELUGU -> teluguTitle
            AppLanguage.HINDI -> hindiTitle
            AppLanguage.TAMIL -> tamilTitle
            AppLanguage.KANNADA -> kannadaTitle
            AppLanguage.ENGLISH -> englishTitle
        }
    }
}
