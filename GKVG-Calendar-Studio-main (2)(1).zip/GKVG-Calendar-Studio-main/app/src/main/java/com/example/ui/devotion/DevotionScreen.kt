package com.example.ui.devotion

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.StotramItem
import com.example.data.model.WallpaperItem
import com.example.data.sample.SampleDevotionRepository
import com.example.ui.components.DailyDeityCard
import com.example.ui.components.DailyVerseCard
import com.example.ui.components.RingtonePlayerCard
import com.example.ui.components.WallpaperPreviewDialog
import com.example.ui.theme.RoyalBlue800
import com.example.ui.theme.RoyalBlue900
import com.example.ui.theme.SacredGold300
import com.example.ui.theme.SacredGold400
import com.example.ui.theme.SacredGold500
import com.example.ui.theme.SacredGold700
import com.example.ui.viewmodel.AppViewModel
import java.time.LocalDate

@Composable
fun DevotionScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.currentLanguage.collectAsState()
    val selectedWallpaper by viewModel.selectedWallpaperForPreview.collectAsState()
    val playingRingtoneId by viewModel.playingRingtoneId.collectAsState()

    val todayDeity = remember { SampleDevotionRepository.getDailyDeity(LocalDate.now().dayOfWeek) }
    val verses = remember { SampleDevotionRepository.getAllVerses() }
    val wallpapers = remember { SampleDevotionRepository.getAllWallpapers() }
    val ringtones = remember { SampleDevotionRepository.getAllRingtones() }
    val stotrams = remember { SampleDevotionRepository.getAllStotrams() }

    // Wallpaper Preview Dialog
    selectedWallpaper?.let { wp ->
        WallpaperPreviewDialog(
            wallpaper = wp,
            language = language,
            onDismiss = { viewModel.previewWallpaper(null) }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("devotion_screen_content"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Daily Deity Section
        item {
            DailyDeityCard(
                deity = todayDeity,
                language = language
            )
        }

        // Sacred Wallpapers Horizontal Shelf
        item {
            Column {
                SectionHeader(
                    title = "దివ్య వాల్‌పేపర్లు (Devotional Wallpapers)",
                    subtitle = "HD Temple & Deity Backgrounds",
                    icon = Icons.Default.Wallpaper
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    wallpapers.forEach { wallpaper ->
                        WallpaperCardItem(
                            wallpaper = wallpaper,
                            language = language,
                            onClick = { viewModel.previewWallpaper(wallpaper) }
                        )
                    }
                }
            }
        }

        // Daily Devotional Verses / Slokas
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeader(
                    title = "దివ్య శ్లోకాలు & మంత్రాలు (Daily Slokas)",
                    subtitle = "Sacred Chants & Vedic Blessings",
                    icon = Icons.Default.MenuBook
                )
                verses.forEach { verse ->
                    DailyVerseCard(
                        verse = verse,
                        language = language
                    )
                }
            }
        }

        // Devotional Audio & Ringtones
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeader(
                    title = "భక్తి రింగ్‌టోన్లు & శంఖారావం (Ringtones)",
                    subtitle = "Temple Chimes, Suprabhatam & Mantras",
                    icon = Icons.Default.MusicNote
                )
                ringtones.forEach { ringtone ->
                    RingtonePlayerCard(
                        ringtone = ringtone,
                        isPlaying = playingRingtoneId == ringtone.id,
                        language = language,
                        onTogglePlay = { viewModel.toggleRingtonePlay(ringtone.id) }
                    )
                }
            }
        }

        // Sacred Stotrams Library
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeader(
                    title = "నిత్య పారాయణ స్తోత్రాలు (Stotram Library)",
                    subtitle = "Sahasranama & Vedic Stotrams",
                    icon = Icons.Default.AutoAwesome
                )
                stotrams.forEach { stotram ->
                    StotramCardItem(
                        stotram = stotram,
                        language = language
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SectionHeader(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(SacredGold500.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun WallpaperCardItem(
    wallpaper: WallpaperItem,
    language: AppLanguage,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.2.dp, SacredGold500.copy(alpha = 0.4f)),
        modifier = Modifier
            .width(130.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("wallpaper_item_${wallpaper.id}")
    ) {
        Column {
            // Visual Card Preview Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(wallpaper.primaryColorHex),
                                Color(wallpaper.secondaryColorHex).copy(alpha = 0.85f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "ॐ",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = SacredGold300
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = wallpaper.deity.get(language).substringBefore(" "),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            Column(
                modifier = Modifier.padding(10.dp)
            ) {
                Text(
                    text = wallpaper.title.get(language),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
                Text(
                    text = "Tap to view",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

@Composable
private fun StotramCardItem(
    stotram: StotramItem,
    language: AppLanguage
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stotram.title.get(language),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = stotram.description.get(language),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = SacredGold500.copy(alpha = 0.15f),
                border = BorderStroke(0.8.dp, SacredGold500.copy(alpha = 0.4f))
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${stotram.versesCount}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "Slokas",
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
