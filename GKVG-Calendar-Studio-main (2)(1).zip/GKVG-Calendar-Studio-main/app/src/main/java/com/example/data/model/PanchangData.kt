package com.example.data.model

import java.time.LocalDate

data class PanchangData(
    val date: LocalDate,
    val samvatsaram: LocalizedText,
    val ayanam: LocalizedText,
    val rutu: LocalizedText,
    val masam: LocalizedText,
    val paksham: LocalizedText,
    val tithi: LocalizedText,
    val tithiEndTime: String,
    val nakshatram: LocalizedText,
    val nakshatramEndTime: String,
    val yogam: LocalizedText,
    val karanam: LocalizedText,
    val vara: LocalizedText,
    val sunrise: String,
    val sunset: String,
    val moonrise: String,
    val moonset: String,
    val rahukalam: String,
    val yamagandam: String,
    val gulikakalam: String,
    val durmuhurtham: String,
    val varjyam: String,
    val amritakalam: String,
    val abhijitMuhurtham: String,
    val specialFestivalToday: LocalizedText? = null,
    val isAuspiciousDay: Boolean = true
)
