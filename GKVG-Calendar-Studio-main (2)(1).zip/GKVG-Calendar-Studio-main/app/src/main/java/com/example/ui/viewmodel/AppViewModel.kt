package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.model.AppLanguage
import com.example.data.model.Festival
import com.example.data.model.FestivalCategory
import com.example.data.model.HoroscopeTimeframe
import com.example.data.model.PanchangData
import com.example.data.model.PanchangLocation
import com.example.data.model.RasiPhalalu
import com.example.data.model.StandardLocations
import com.example.data.model.ThemeMode
import com.example.data.model.WallpaperItem
import com.example.data.model.ZodiacSign
import com.example.data.sample.SampleDevotionRepository
import com.example.data.sample.SampleFestivalRepository
import com.example.data.sample.SamplePanchangRepository
import com.example.data.sample.SampleRasiRepository
import com.example.ui.navigation.AppNavigationTab
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate
import java.time.YearMonth

class AppViewModel : ViewModel() {

    private val _isSplashActive = MutableStateFlow(true)
    val isSplashActive: StateFlow<Boolean> = _isSplashActive.asStateFlow()

    private val _currentTab = MutableStateFlow(AppNavigationTab.HOME)
    val currentTab: StateFlow<AppNavigationTab> = _currentTab.asStateFlow()

    private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _currentLanguage = MutableStateFlow(AppLanguage.TELUGU)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _selectedDate = MutableStateFlow(LocalDate.now())
    val selectedDate: StateFlow<LocalDate> = _selectedDate.asStateFlow()

    private val _calendarMonth = MutableStateFlow(YearMonth.now())
    val calendarMonth: StateFlow<YearMonth> = _calendarMonth.asStateFlow()

    private val _selectedFestivalCategory = MutableStateFlow(FestivalCategory.ALL)
    val selectedFestivalCategory: StateFlow<FestivalCategory> = _selectedFestivalCategory.asStateFlow()

    private val _selectedRasiSign = MutableStateFlow(ZodiacSign.MESHA)
    val selectedRasiSign: StateFlow<ZodiacSign> = _selectedRasiSign.asStateFlow()

    private val _isRasiModalOpen = MutableStateFlow(false)
    val isRasiModalOpen: StateFlow<Boolean> = _isRasiModalOpen.asStateFlow()

    private val _horoscopeTimeframe = MutableStateFlow(HoroscopeTimeframe.TODAY)
    val horoscopeTimeframe: StateFlow<HoroscopeTimeframe> = _horoscopeTimeframe.asStateFlow()

    private val _selectedWallpaperForPreview = MutableStateFlow<WallpaperItem?>(null)
    val selectedWallpaperForPreview: StateFlow<WallpaperItem?> = _selectedWallpaperForPreview.asStateFlow()

    private val _playingRingtoneId = MutableStateFlow<String?>(null)
    val playingRingtoneId: StateFlow<String?> = _playingRingtoneId.asStateFlow()

    private val _selectedLocation = MutableStateFlow(StandardLocations[0]) // Hyderabad
    val selectedLocation: StateFlow<PanchangLocation> = _selectedLocation.asStateFlow()

    private val _morningNotification = MutableStateFlow(true)
    val morningNotification: StateFlow<Boolean> = _morningNotification.asStateFlow()

    private val _festivalNotification = MutableStateFlow(true)
    val festivalNotification: StateFlow<Boolean> = _festivalNotification.asStateFlow()

    private val _rahuKalamAlert = MutableStateFlow(false)
    val rahuKalamAlert: StateFlow<Boolean> = _rahuKalamAlert.asStateFlow()

    private val _isLanguageDialogOpen = MutableStateFlow(false)
    val isLanguageDialogOpen: StateFlow<Boolean> = _isLanguageDialogOpen.asStateFlow()

    private val _isLocationDialogOpen = MutableStateFlow(false)
    val isLocationDialogOpen: StateFlow<Boolean> = _isLocationDialogOpen.asStateFlow()

    private val _isPanchangExpanded = MutableStateFlow(false)
    val isPanchangExpanded: StateFlow<Boolean> = _isPanchangExpanded.asStateFlow()

    // Splash
    fun dismissSplash() {
        _isSplashActive.value = false
    }

    // Navigation
    fun selectTab(tab: AppNavigationTab) {
        _currentTab.value = tab
    }

    // Theme
    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    // Language
    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }

    fun openLanguageDialog() {
        _isLanguageDialogOpen.value = true
    }

    fun closeLanguageDialog() {
        _isLanguageDialogOpen.value = false
    }

    // Location
    fun setLocation(location: PanchangLocation) {
        _selectedLocation.value = location
    }

    fun openLocationDialog() {
        _isLocationDialogOpen.value = true
    }

    fun closeLocationDialog() {
        _isLocationDialogOpen.value = false
    }

    // Date & Calendar
    fun selectDate(date: LocalDate) {
        _selectedDate.value = date
        _calendarMonth.value = YearMonth.from(date)
    }

    fun goToPreviousMonth() {
        _calendarMonth.value = _calendarMonth.value.minusMonths(1)
    }

    fun goToNextMonth() {
        _calendarMonth.value = _calendarMonth.value.plusMonths(1)
    }

    fun jumpToToday() {
        val today = LocalDate.now()
        _selectedDate.value = today
        _calendarMonth.value = YearMonth.from(today)
    }

    // Festivals
    fun setFestivalCategory(category: FestivalCategory) {
        _selectedFestivalCategory.value = category
    }

    // Rasi Phalalu
    fun openRasiModal(sign: ZodiacSign? = null) {
        if (sign != null) {
            _selectedRasiSign.value = sign
        }
        _isRasiModalOpen.value = true
    }

    fun closeRasiModal() {
        _isRasiModalOpen.value = false
    }

    fun selectRasiSign(sign: ZodiacSign) {
        _selectedRasiSign.value = sign
    }

    fun setHoroscopeTimeframe(timeframe: HoroscopeTimeframe) {
        _horoscopeTimeframe.value = timeframe
    }

    // Devotion
    fun previewWallpaper(wallpaper: WallpaperItem?) {
        _selectedWallpaperForPreview.value = wallpaper
    }

    fun toggleRingtonePlay(ringtoneId: String) {
        if (_playingRingtoneId.value == ringtoneId) {
            _playingRingtoneId.value = null
        } else {
            _playingRingtoneId.value = ringtoneId
        }
    }

    // Toggles
    fun toggleMorningNotification(value: Boolean) {
        _morningNotification.value = value
    }

    fun toggleFestivalNotification(value: Boolean) {
        _festivalNotification.value = value
    }

    fun toggleRahuKalamAlert(value: Boolean) {
        _rahuKalamAlert.value = value
    }

    fun togglePanchangExpanded() {
        _isPanchangExpanded.value = !_isPanchangExpanded.value
    }

    // Convenience Getters for UI
    fun getPanchangForSelectedDate(): PanchangData {
        return SamplePanchangRepository.getPanchangForDate(_selectedDate.value)
    }

    fun getTodayPanchang(): PanchangData {
        return SamplePanchangRepository.getPanchangForDate(LocalDate.now())
    }

    fun getFestivalsForSelectedDate(): List<Festival> {
        return SampleFestivalRepository.getFestivalsForDate(_selectedDate.value)
    }

    fun getUpcomingFestivals(): List<Festival> {
        return SampleFestivalRepository.getUpcomingFestivals(LocalDate.now(), limit = 6)
    }

    fun getFestivalsForCategory(category: FestivalCategory): List<Festival> {
        val all = SampleFestivalRepository.getAllFestivals()
        return if (category == FestivalCategory.ALL) all else all.filter { it.category == category }
    }

    fun getCurrentRasiData(): RasiPhalalu {
        return SampleRasiRepository.getRasi(_selectedRasiSign.value)
    }
}
