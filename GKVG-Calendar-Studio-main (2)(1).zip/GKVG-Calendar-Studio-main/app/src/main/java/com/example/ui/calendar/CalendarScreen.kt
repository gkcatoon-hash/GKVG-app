package com.example.ui.calendar

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.Festival
import com.example.data.model.PanchangData
import com.example.data.sample.SampleFestivalRepository
import com.example.data.sample.SamplePanchangRepository
import com.example.ui.theme.AuspiciousSaffron
import com.example.ui.theme.RoyalBlue800
import com.example.ui.theme.RoyalBlue900
import com.example.ui.theme.SacredGold300
import com.example.ui.theme.SacredGold400
import com.example.ui.theme.SacredGold500
import com.example.ui.theme.SacredGold600
import com.example.ui.theme.SacredGold700
import com.example.ui.viewmodel.AppViewModel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.WeekFields
import java.util.Locale

@Composable
fun CalendarScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.currentLanguage.collectAsState()
    val currentMonth by viewModel.calendarMonth.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()
    val today = LocalDate.now()

    val selectedPanchang = SamplePanchangRepository.getPanchangForDate(selectedDate)
    val selectedDateFestivals = SampleFestivalRepository.getFestivalsForDate(selectedDate)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("calendar_screen_content"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Month Navigation Card & Calendar Grid
        item {
            CalendarCard(
                month = currentMonth,
                today = today,
                selectedDate = selectedDate,
                language = language,
                onPreviousMonth = { viewModel.goToPreviousMonth() },
                onNextMonth = { viewModel.goToNextMonth() },
                onTodayClick = { viewModel.jumpToToday() },
                onDateSelected = { date -> viewModel.selectDate(date) }
            )
        }

        // Selected Date Panchang & Details Summary Area
        item {
            SelectedDateDetailsCard(
                date = selectedDate,
                panchang = selectedPanchang,
                festivals = selectedDateFestivals,
                language = language
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun CalendarCard(
    month: YearMonth,
    today: LocalDate,
    selectedDate: LocalDate,
    language: AppLanguage,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onTodayClick: () -> Unit,
    onDateSelected: (LocalDate) -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.2.dp, SacredGold500.copy(alpha = 0.45f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("calendar_grid_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Month Header with Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onPreviousMonth,
                    modifier = Modifier.testTag("previous_month_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronLeft,
                        contentDescription = "Previous Month",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = month.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "శ్రీ క్రోధి నామ సంవత్సరం",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Jump to Today button
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SacredGold500.copy(alpha = 0.15f),
                        border = BorderStroke(0.8.dp, SacredGold500.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onTodayClick() }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                            .testTag("jump_to_today_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Today,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Today",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    IconButton(
                        onClick = onNextMonth,
                        modifier = Modifier.testTag("next_month_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Next Month",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Day of Week Header Row (Sun to Sat)
            val daysOfWeek = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
            val teluguDays = listOf("ఆది", "సోమ", "మంగళ", "బుధ", "గురు", "శుక్ర", "శని")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                daysOfWeek.forEachIndexed { index, day ->
                    val isSunday = index == 0
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = day,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSunday) AuspiciousSaffron else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = teluguDays[index],
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(8.dp))

            // Month Grid Calculations
            val firstDayOfMonth = month.atDay(1)
            val daysInMonth = month.lengthOfMonth()
            // In java.time DayOfWeek: Mon=1, Sun=7. We want Sun=0, Mon=1... Sat=6
            val firstDayOffset = firstDayOfMonth.dayOfWeek.value % 7

            val totalCells = ((firstDayOffset + daysInMonth + 6) / 7) * 7

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (week in 0 until totalCells / 7) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        for (dayOfWeek in 0 until 7) {
                            val cellIndex = week * 7 + dayOfWeek
                            val dayOfMonth = cellIndex - firstDayOffset + 1

                            if (dayOfMonth in 1..daysInMonth) {
                                val date = month.atDay(dayOfMonth)
                                val isSelected = date == selectedDate
                                val isToday = date == today
                                val hasFestival = SampleFestivalRepository.getFestivalsForDate(date).isNotEmpty()

                                CalendarDayCell(
                                    date = date,
                                    isSelected = isSelected,
                                    isToday = isToday,
                                    hasFestival = hasFestival,
                                    onClick = { onDateSelected(date) },
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Box(modifier = Modifier.weight(1f).aspectRatio(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarDayCell(
    date: LocalDate,
    isSelected: Boolean,
    isToday: Boolean,
    hasFestival: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSunday = date.dayOfWeek == DayOfWeek.SUNDAY

    val backgroundColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        isToday -> SacredGold500.copy(alpha = 0.25f)
        else -> Color.Transparent
    }

    val textColor = when {
        isSelected -> MaterialTheme.colorScheme.onPrimary
        isToday -> MaterialTheme.colorScheme.primary
        isSunday -> AuspiciousSaffron
        else -> MaterialTheme.colorScheme.onSurface
    }

    val borderColor = when {
        isSelected -> SacredGold500
        isToday -> SacredGold500
        else -> Color.Transparent
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = backgroundColor,
        border = if (borderColor != Color.Transparent) BorderStroke(1.2.dp, borderColor) else null,
        modifier = modifier
            .aspectRatio(1f)
            .padding(2.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag("calendar_day_${date.dayOfMonth}")
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text = date.dayOfMonth.toString(),
                fontSize = 14.sp,
                fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Medium,
                color = textColor
            )

            // Festival / Special Auspicious Dot Indicator
            if (hasFestival) {
                Box(
                    modifier = Modifier
                        .size(4.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) SacredGold300 else AuspiciousSaffron)
                )
            }
        }
    }
}

@Composable
private fun SelectedDateDetailsCard(
    date: LocalDate,
    panchang: PanchangData,
    festivals: List<Festival>,
    language: AppLanguage
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.2.dp, SacredGold500.copy(alpha = 0.45f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("selected_date_details_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Selected Date Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ఎంపిక చేసిన తేదీ వివరాలు (Selected Date)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = date.format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy")),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SacredGold500.copy(alpha = 0.15f),
                    border = BorderStroke(0.8.dp, SacredGold500.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = panchang.vara.get(language).substringBefore(" "),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Festivals on selected date
            if (festivals.isNotEmpty()) {
                festivals.forEach { festival ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SacredGold500.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, SacredGold500.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "🎉 ${festival.name.get(language)}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = festival.description.get(language),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Panchang Details for Selected Date
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailItem("తిథి (Tithi)", panchang.tithi.get(language))
                        DetailItem("నక్షత్రం (Nakshatram)", panchang.nakshatram.get(language))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailItem("సూర్యోదయం", panchang.sunrise)
                        DetailItem("సూర్యాస్తమయం", panchang.sunset)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailItem("రాహుకాలం", panchang.rahukalam)
                        DetailItem("యమగండం", panchang.yamagandam)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailItem(label: String, value: String) {
    Column {
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
