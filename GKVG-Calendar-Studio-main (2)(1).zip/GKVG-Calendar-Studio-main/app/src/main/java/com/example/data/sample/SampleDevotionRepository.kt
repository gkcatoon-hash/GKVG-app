package com.example.data.sample

import com.example.data.model.DailyDeity
import com.example.data.model.DevotionalVerse
import com.example.data.model.LocalizedText
import com.example.data.model.RingtoneItem
import com.example.data.model.StotramItem
import com.example.data.model.WallpaperItem
import java.time.DayOfWeek

object SampleDevotionRepository {

    private val dailyDeities = mapOf(
        DayOfWeek.SUNDAY to DailyDeity(
            dayOfWeek = DayOfWeek.SUNDAY,
            deityName = LocalizedText("Surya Bhagavan (Sun God)", "శ్రీ సూర్య భగవానుడు", "सूर्य भगवान", "சூரிய பகவான்", "ಸೂರ್ಯ ಭಗವಾನ್"),
            title = LocalizedText("Lord of Light & Health (Arogya Pradata)", "ఆరోగ్య ప్రదాత, జగచ్చక్షువు", "आरोग्य एवं प्रकाश के देव", "ஆரோக்கியம் தரும் சூரியன்", "ಆರೋಗ್ಯ ಪ್ರದಾತ ಸೂರ್ಯ"),
            specialPooja = LocalizedText("Surya Namaskaram & Gayatri Japa", "సూర్య నమస్కారాలు, గాయత్రీ జపము", "सूर्य नमस्कार एवं गायत्री जप", "சூரிய நமஸ்காரம் மற்றும் காயத்ரி ஜபம்", "ಸೂರ್ಯ ನಮಸ್ಕಾರ ಮತ್ತು ಗಾಯತ್ರಿ ಜಪ"),
            sacredChant = "ॐ సూర్యాయ నమః | Om Suryaya Namaha",
            auspiciousColor = LocalizedText("Ruby Red & Copper", "ఎరుపు, కాషాయం", "लाल", "சிகப்பு", "ಕೆಂಪು"),
            flowerOffering = LocalizedText("Red Hibiscus (Mandarachettu)", "ఎర్ర మందార పుష్పాలు", "लाल गुड़हल", "செம்பருத்தி", "ದಾಸವಾಳ"),
            templeSpotlight = LocalizedText("Arasavalli Sun Temple / Konark", "అరసవల్లి సూర్యనారాయణ స్వామి దేవాలయం", "कोणार्क सूर्य मंदिर", "சூரியனார் கோவில்", "ಅರಸವಲ್ಲಿ ಸೂರ್ಯ ದೇವಾಲಯ")
        ),
        DayOfWeek.MONDAY to DailyDeity(
            dayOfWeek = DayOfWeek.MONDAY,
            deityName = LocalizedText("Lord Parama Shiva", "శ్రీ పరమేశ్వరుడు (శివుడు)", "भगवान शिव", "சிவபெருமான்", "ಪರಮಶಿವ"),
            title = LocalizedText("The Auspicious Destroyer of Darkness (Mahadeva)", "మహాదేవుడు, భోళాశంకరుడు", "महादेव, आशुतोष", "மகா தேவன்", "ಮಹಾದೇವ ಭೋಳೇಶಂಕರ"),
            specialPooja = LocalizedText("Bilvarchana & Rudrabhishekam", "బిల్వార్చన, ఏకాదశ రుద్రాభిషేకం", "बिल्वार्चन एवं रुद्राभिषेक", "வில்வார்ச்சனை மற்றும் ருத்ராபிஷேகம்", "ಬಿಲ್ವಾರ್ಚನೆ ಮತ್ತು ರುದ್ರಾಭಿಷೇಕ"),
            sacredChant = "ॐ నమః శివాయ | Om Namah Shivaya",
            auspiciousColor = LocalizedText("Pure White & Silver", "స్వచ్ఛమైన తెలుపు, వెండి", "सफेद", "வெள்ளை", "ಬಿಳಿ"),
            flowerOffering = LocalizedText("Bilva Leaves & White Jasmine", "మారేడు దళాలు (బిల్వ పత్రాలు), మల్లెలు", "बेलपत्र एवं श्वेत पुष्प", "வில்வ இலை", "ಬಿಲ್ವ ಪತ್ರೆ"),
            templeSpotlight = LocalizedText("Srisailam Mallikarjuna Swamy / Kashi", "శ్రీశైలం భ్రమరాంబ సమేత మల్లికార్జున స్వామి", "काशी विश्वनाथ", "ராமேஸ்வரம் ராமநாதர்", "ಶ್ರೀಶೈಲ ಮಲ್ಲಿಕಾರ್ಜುನ ಸ್ವಾಮಿ")
        ),
        DayOfWeek.TUESDAY to DailyDeity(
            dayOfWeek = DayOfWeek.TUESDAY,
            deityName = LocalizedText("Lord Hanuman & Sri Subrahmanya Swamy", "శ్రీ హనుమాన్ & శ్రీ సుబ్రహ్మణ్య స్వామి", "श्री हनुमान एवं कार्तिकेय", "அனுமன் & முருகப் பெருமான்", "ಶ್ರೀ ಹನುಮಂತ ಮತ್ತು ಸುಬ್ರಹ್ಮಣ್ಯ"),
            title = LocalizedText("Remover of Obstacles & Evil (Sankat Mochan)", "సంకట మోచనుడు, ధైర్య ప్రదాత", "संकटमोचन, शक्ति स्वरूप", "சங்கடம் தீர்க்கும் அனுமன்", "ಸಂಕಟಮೋಚಕ ಹನುಮಂತ"),
            specialPooja = LocalizedText("Sindhoora Pooja & Vadamala Offering", "సింధూర పూజ, తమలపాకుల పూజ, వడమాల సమర్పణ", "सिंदूर पूजा एवं सुंदरकांड", "செந்தூர பூஜை", "ಸಿಂಧೂರ ಪೂಜೆ, ವಡಮಾಲೆ"),
            sacredChant = "ॐ హం హనుమతే నమః | Om Ham Hanumate Namaha",
            auspiciousColor = LocalizedText("Vermilion & Deep Orange", "సింధూరం, ముదురు నారింజ", "केसरिया", "காவி", "ಕೇಸರಿ"),
            flowerOffering = LocalizedText("Betel Leaves & Red Oleander", "తమలపాకులు, గన్నేరు పూలు", "तुलसी व लाल फूल", "வெற்றிலை மாலை", "ವೀಳ್ಯದೆಲೆ ಮಾಲೆ"),
            templeSpotlight = LocalizedText("Kasapuram Nettikanti Hanuman / Palani", "కసాపురం నెట్టికంటి ఆంజనేయ స్వామి దేవాలయం", "हनुमान गढ़ी अयोध्या", "பழனி முருகன் கோவில்", "ಘಾಟಿ ಸುಬ್ರಹ್ಮಣ್ಯ ದೇವಾಲಯ")
        ),
        DayOfWeek.WEDNESDAY to DailyDeity(
            dayOfWeek = DayOfWeek.WEDNESDAY,
            deityName = LocalizedText("Lord Vigneshwara (Ganesha)", "శ్రీ విఘ్నేశ్వరుడు (గణపతి)", "भगवान श्री गणेश", "விநாயகப் பெருமான்", "ಶ್ರೀ ಗಣೇಶ"),
            title = LocalizedText("Lord of Wisdom & Beginnings (Prathama Pujya)", "విద్యా బుద్ధి ప్రదాత, సర్వ విఘ్నహర్త", "प्रथम पूज्य, विघ्नहर्ता", "முதற்கடவுள் விநாயகர்", "ವಿಘ್ನನಿವಾರಕ ಗಣೇಶ"),
            specialPooja = LocalizedText("Durvankura Pooja & Modak Offering", "గరిక పూజ (దూర్వాయుగ్మం), ఉండ్రాళ్ళ నివేదన", "दूर्वा एवं मोदक अर्पण", "அருகம்புல் அர்ச்சனை", "ಗರಿಕೆ ಹುಲ್ಲಿನ ಪೂಜೆ"),
            sacredChant = "ॐ గం గణపతయే నమః | Om Gam Ganapataye Namaha",
            auspiciousColor = LocalizedText("Fresh Emerald Green & Golden Yellow", "ఆకుపచ్చ, పసుపు", "हरा व पीला", "பச்சை", "ಹಸಿರು"),
            flowerOffering = LocalizedText("Durva Grass (Garika) & Red Hibiscus", "గరిక (దూర్వాంకురాలు), జిల్లేడు పూలు", "दूर्वा एवं लाल पुष्प", "அருகம்புல்", "ಗರಿಕೆ ಮತ್ತು ದಾಸವಾಳ"),
            templeSpotlight = LocalizedText("Kanipakam Varasiddhi Vinayaka Swamy", "కాణిపాకం శ్రీ వరసిద్ధి వినాయక స్వామి దేవాలయం", "सिद्धिविनायक मुंबई", "பிள்ளையார்பட்டி கற்பக விநாயகர்", "ಇಡಗುಂಜಿ ಗಣಪತಿ ದೇವಾಲಯ")
        ),
        DayOfWeek.THURSDAY to DailyDeity(
            dayOfWeek = DayOfWeek.THURSDAY,
            deityName = LocalizedText("Lord Dattatreya, Shirdi Sai Baba & Raghavendra Swamy", "శ్రీ దత్తాత్రేయ స్వామి & శ్రీ గురు రాఘవేంద్రులు", "भगवान दत्तात्रेय एवं गुरुदेव", "குரு தட்சிணாமூர்த்தி & ராகவேந்திரர்", "ಶ್ರೀ ದತ್ತಾತ್ರೇಯ ಮತ್ತು ರಾಘವೇಂದ್ರ ಸ್ವಾಮಿ"),
            title = LocalizedText("The Supreme Teacher & Dispeller of Ignorance", "జగద్గురువు, భక్త సులభుడు", "सद्गुरु, ज्ञानदाता", "ஞான குரு", "ಜ್ಞಾನದಾತ ಸದ್ಗುರು"),
            specialPooja = LocalizedText("Guru Paduka Pooja & Sai Satcharitra Parayana", "గురు పాదుకా పూజ, సాయి సచ్చరిత్ర పారాయణ", "गुरु पादुका पूजन", "குரு பாத பூஜை", "ಗುರು ಪಾದುಕ ಪೂಜೆ"),
            sacredChant = "ॐ గురుభ్యో నమః | Om Dattatreyaaya Namaha",
            auspiciousColor = LocalizedText("Golden Yellow & Amber", "పసుపు వర్ణం, బంగారు రంగు", "पीला", "மஞ்சள்", "ಹಳದಿ"),
            flowerOffering = LocalizedText("Yellow Marigold & Chrysanthemum", "పసుపు చామంతి, బంతి పూలు", "पीले गेंदे के फूल", "மஞ்சள் சாமந்தி", "ಹಳದಿ ಸೇವಂತಿಗೆ"),
            templeSpotlight = LocalizedText("Mantralayam Sri Raghavendra Swamy Mutt / Shirdi", "మంత్రాలయం శ్రీ గురు రాఘవేంద్ర స్వామి బృందావనం", "शिरडी साईं धाम", "திருச்செந்தூர்", "ಮಂತ್ರಾಲಯ ರಾಘವೇಂದ್ರ ಮಠ")
        ),
        DayOfWeek.FRIDAY to DailyDeity(
            dayOfWeek = DayOfWeek.FRIDAY,
            deityName = LocalizedText("Goddess Sri Mahalakshmi & Sri Lalitha Tripurasundari", "శ్రీ మహాలక్ష్మి & జగన్మాత లలితా దేవి", "माता महालक्ष्मी व दुर्गा", "மகாலட்சுமி & துர்க்கை அம்மன்", "ಶ್ರೀ ಮಹಾಲಕ್ಷ್ಮಿ ಮತ್ತು ದುರ್ಗಾದೇವಿ"),
            title = LocalizedText("Goddess of Wealth, Grace & Prosperity (Soubhagya Dayini)", "సకల సౌభాగ్య ప్రదాయిని, ధనధాన్య లక్ష్మి", "सौभाग्य एवं ऐश्वर्य दात्री", "அஷ்ட ஐஸ்வர்யம் தரும் தாய்", "ಸೌಭಾಗ್ಯದಾಯಿನಿ ಮಹಾಲಕ್ಷ್ಮಿ"),
            specialPooja = LocalizedText("Kumkuma Archana & Sri Sukta Parayana", "కుంకుమార్చన, శ్రీసూక్త లలితా సహస్రనామ పారాయణ", "कुंकुमार्चन एवं श्रीसूक्त पाठ", "குங்கும அர்ச்சனை", "ಕುಂಕುಮಾರ್ಚನೆ, ಶ್ರೀ ಸೂಕ್ತ ಪಠಣ"),
            sacredChant = "ॐ శ్రీం మహాలక్ష్మ్యై నమః | Om Shreem Mahalakshmyai Namaha",
            auspiciousColor = LocalizedText("Divine Pink & Royal Crimson", "గులాబీ, ఎరుపు, పట్టు వర్ణం", "गुलाबी व लाल", "ரோஸ் மற்றும் சிகப்பு", "ಗುಲಾಬಿ ಮತ್ತು ಕೆಂಪು"),
            flowerOffering = LocalizedText("Red & Pink Lotus Flowers", "కమలములు (తామర పూలు), సుగంధ పుష్పాలు", "कमल पुष्प", "தாமரை மலர்", "ಕಮಲದ ಹೂವು"),
            templeSpotlight = LocalizedText("Tiruchanur Sri Padmavathi Ammavari Temple / Kolhapur", "తిరుచానూరు శ్రీ పద్మావతి అమ్మవారి దివ్య క్షేత్రం", "महालक्ष्मी कोल्हापुर", "மதுரை மீனாட்சி அம்மன்", "ಕೊಲ್ಲೂರು ಮೂಕಾಂಬಿಕಾ ದೇವಾಲಯ")
        ),
        DayOfWeek.SATURDAY to DailyDeity(
            dayOfWeek = DayOfWeek.SATURDAY,
            deityName = LocalizedText("Lord Sri Venkateswara Swamy (Balaji)", "శ్రీ వేంకటేశ్వర స్వామి (తిరుమల బాలాజీ)", "भगवान श्री वेंकटेश्वर (बालाजी)", "ஏழுமலையான் திருப்பதி பாலாஜி", "ಶ್ರೀ ವೆಂಕಟೇಶ್ವರ ಸ್ವಾಮಿ (ಬಾಲಾಜಿ)"),
            title = LocalizedText("The Kaliyuga Vaikuntha Lord (Govinda)", "కలియుగ ప్రత్యక్ష దైవం, అఖిలాండకోటి బ్రహ్మాండ నాయకుడు", "कलयुग के प्रत्यक्ष देव", "கலியுக வரதன்", "ಕಲಿಯುಗದ ಪ್ರತ್ಯಕ್ಷ ದೈವ ಗೋವಿಂದ"),
            specialPooja = LocalizedText("Suprabhatam, Vishnu Sahasranama & Deeparadhana", "సుప్రభాతం, విష్ణు సహస్రనామార్చన, నువ్వుల నూనె దీపారాధన", "सुप्रभातम् एवं दीप आराधना", "சுப்ரபாதம் மற்றும் அர்ச்சனை", "ಸುಪ್ರಭಾತ, ವಿಷ್ಣು ಸಹಸ್ರನಾಮ ಪೂಜೆ"),
            sacredChant = "ॐ నమో వేంకటేశాయ | Govinda Govinda",
            auspiciousColor = LocalizedText("Royal Deep Blue & Golden Zari", "రాజనీలం, పీతాంబర వర్ణం", "नीला व पीताम्बरी", "நீலம் மற்றும் தங்கம்", "ನೀಲಿ ಮತ್ತು ರೇಷ್ಮೆ ಬಣ್ಣ"),
            flowerOffering = LocalizedText("Tulasi Dalams & Lotus Garland", "తులసీ దళములు, జాజి పూలు", "तुलसी दल", "துளசி மாலை", "ತುಳಸಿ ಮಾಲೆ"),
            templeSpotlight = LocalizedText("Tirumala Tirupati Sri Venkateswara Swamy Temple", "కలియుగ వైకుంఠం తిరుమల తిరుపతి దేవస్థానం", "तिरुपति बालाजी धाम", "திருமலை திருப்பதி ஏழுமலையான்", "ತಿರುಮಲ ತಿರುಪತಿ ಬಾಲಾಜಿ ಕ್ಷೇತ್ರ")
        )
    )

    private val sampleVerses = listOf(
        DevotionalVerse(
            id = "sloka_1",
            title = LocalizedText("Ganesha Mangala Slokam", "గణేశ మంగళ శ్లోకం", "गणेश श्लोक", "விநாயகர் ஸ்லோகம்", "ಗಣೇಶ ಶ್ಲೋಕ"),
            slokaOriginal = "శుక్లాంబరధరం విష్ణుం శశివర్ణం చతుర్భుజమ్ |\nప్రసన్నవదనం ధ్యాయేత్ సర్వవిఘ్నోపశాంతయే ||",
            transliteration = "Suklambaradharam Vishnum Sasivarnam Chaturbhujam |\nPrasanna Vadanam Dhyayet Sarva Vighnopashantaye ||",
            meaning = LocalizedText(
                "We meditate on Lord Vishnu/Ganesha, who wears white clothes, is all-pervading, bright as the moon, having four arms, and with a serene, pleasant face to pacify all obstacles.",
                "తెల్లని వస్త్రములు ధరించి, సర్వవ్యాపియై, చంద్రుని వంటి కాంతిగలవాడై, నాలుగు చేతులు కలిగి, ప్రశాంతమైన ముఖముతో ప్రకాశించే స్వామిని సర్వ విఘ్నములు తొలగిపోవడానికి ధ్యానిస్తున్నాను.",
                "श्वेत वस्त्रधारी, सर्वव्यापी, चतुर्भुज एवं शांत मुख वाले भगवान का सभी विघ्नों के निवारण हेतु ध्यान करते हैं।",
                "அனைத்து தடைகளையும் நீக்க வெண்ணிற ஆடை தரித்த கணபதியை தியானிக்கிறோம்.",
                "ಸರ್ವ ವಿಘ್ನಗಳ ನಿವಾರಣೆಗಾಗಿ ಪ್ರಸನ್ನ ಮುಖದ ಗಣೇಶನನ್ನು ಧ್ಯಾನಿಸುತ್ತೇವೆ."
            ),
            source = LocalizedText("Vedic Mangalacharanam", "వైదిక మంగళాచరణం", "वैदिक मंगलाचरण", "வேத ஸ்லோகம்", "ವೈದಿಕ ಮಂಗಳಾಚರಣೆ"),
            deity = "Lord Ganesha"
        ),
        DevotionalVerse(
            id = "sloka_2",
            title = LocalizedText("Gayatri Maha Mantra", "గాయత్రీ మహా మంత్రం", "गायत्री महामंत्र", "காயத்ரி மகா மந்திரம்", "ಗಾಯತ್ರಿ ಮಹಾ ಮಂತ್ರ"),
            slokaOriginal = "ఓం భూర్భువస్స్వః | తత్సవితుర్వరేణ్యమ్ |\nభర్గో దేవస్య ధీమహి | ధియో యో నః ప్రచోదయాత్ ||",
            transliteration = "Om Bhur Bhuvah Svah | Tat Savitur Varenyam |\nBhargo Devasya Dheemahi | Dhiyo Yo Nah Prachodayat ||",
            meaning = LocalizedText(
                "We meditate upon the supreme, divine radiant glory of the creator Sun god. May that divine light illuminate and inspire our intellect and wisdom.",
                "భూః, భువః, సువః అను త్రిలోకములను ప్రకాశింపజేయు తేజోమయుడైన సవితృ దేవుని దివ్య తేజస్సును మేము ధ్యానిస్తున్నాము. ఆ పరమాత్మ మన బుద్ధులను సన్మార్గమున నడిపించుగాక.",
                "हम उस प्राणस्वरूप, दुःखनाशक, सुखस्वरूप, श्रेष्ठ, तेजस्वी, पापनाशक, देवस्वरूप परमात्मा को ध्यान में धारण करते हैं, जो हमारी बुद्धि को सन्मार्ग पर प्रेरित करे।",
                "எங்கள் அறிவை நல்வழியில் செலுத்தும் இறைவனின் பேரொளியை தியானிக்கிறோம்.",
                "ನಮ್ಮ ಬುದ್ಧಿಯನ್ನು ಸನ್ಮಾರ್ಗದಲ್ಲಿ ನಡೆಸುವ ಪರಮಾತ್ಮನ ದಿವ್ಯ ತೇಜಸ್ಸನ್ನು ಧ್ಯಾನಿಸುತ್ತೇವೆ."
            ),
            source = LocalizedText("Rigveda Mandala 3", "ఋగ్వేదం తృతీయ మండలం", "ऋग्वेद", "ரிக் வேதம்", "ಋಗ್ವೇದ"),
            deity = "Goddess Gayatri / Surya"
        ),
        DevotionalVerse(
            id = "sloka_3",
            title = LocalizedText("Sri Venkateswara Slokam", "శ్రీ వేంకటేశ్వర దివ్య శ్లోకం", "वेंकटेश्वर श्लोक", "வெங்கடேஸ்வர ஸ்லோகம்", "ವೆಂಕಟೇಶ್ವರ ಶ್ಲೋಕ"),
            slokaOriginal = "శ్రీయః కాంతాయ కళ్యాణనిధయే నిధయేఽర్థినామ్ |\nశ్రీవేంకటనివాసాయ శ్రీనివాసాయ మంగళమ్ ||",
            transliteration = "Sriyah Kantaya Kalyana Nidhaye Nidhaye'rthinam |\nSri Venkata Nivasaya Srinivasaya Mangalam ||",
            meaning = LocalizedText(
                "Mangalam (auspicious glory) to Sri Srinivasa, the beloved consort of Goddess Lakshmi, the treasure-trove of auspiciousness, the fulfiller of all wishes, who resides on Venkatadri hill.",
                "మహాలక్ష్మీ దేవికి ప్రియ వల్లభుడైనవాడు, సర్వ శుభములకు నిలయమైనవాడు, భక్తుల కోరికలను నెరవేర్చు నిధియైనవాడు, వేంకటాద్రిపై నివాసమున్న శ్రీనివాసునికి సర్వ శుభ మంగళములు.",
                "महालक्ष्मी के प्रिय, समस्त मंगलों के धाम, वेंकटाद्रि निवासी भगवान श्रीनिवास को मंगलमय प्रणाम।",
                "லட்சுமியின் மணாளனும் திருப்பதி மலையில் வாசம் செய்யும் ஸ்ரீநிவாச பெருமாளுக்கு மங்களம் உண்டாகட்டும்.",
                "ಮಹಾಲಕ್ಷ್ಮಿಯ ಪ್ರಿಯನಾದ ಶ್ರೀ ವೆಂಕಟೇಶ್ವರನಿಗೆ ಮಂಗಳವಾಗಲಿ."
            ),
            source = LocalizedText("Sri Venkateswara Mangalashasanam", "శ్రీ వేంకటేశ్వర మంగళాశాసనం", "वेंकटेश्वर मंगलाशासन", "வெங்கடேஸ்வர மங்களாசாசனம்", "ವೆಂಕಟೇಶ್ವರ ಮಂಗಳಾಶಾಸನ"),
            deity = "Lord Venkateswara"
        )
    )

    private val sampleWallpapers = listOf(
        WallpaperItem(
            id = "wp_1",
            title = LocalizedText("Tirumala Balaji Divya Darshanam", "తిరుమల బాలాజీ దివ్య దర్శనం", "तिरुपति बालाजी", "திருப்பதி பாலாஜி", "ತಿರುಪತಿ ಬಾಲಾಜಿ"),
            deity = LocalizedText("Lord Venkateswara", "శ్రీ వేంకటేశ్వర స్వామి", "भगवान वेंकटेश्वर", "ஏழுமலையான்", "ವೆಂಕಟೇಶ್ವರ"),
            category = "Temples & Deities",
            primaryColorHex = 0xFF0D1B2A,
            secondaryColorHex = 0xFFD4AF37
        ),
        WallpaperItem(
            id = "wp_2",
            title = LocalizedText("Sri Mahalakshmi Golden Grace", "శ్రీ మహాలక్ష్మి స్వర్ణ కవచం", "महालक्ष्मी स्वर्ण कृपा", "மகாலட்சுமி தாயார்", "ಮಹಾಲಕ್ಷ್ಮಿ ಕೃಪೆ"),
            deity = LocalizedText("Goddess Lakshmi", "శ్రీ మహాలక్ష్మి అమ్మవారు", "माता लक्ष्मी", "லட்சுமி தேவி", "ಮಹಾಲಕ್ಷ್ಮಿ"),
            category = "Goddess & Soubhagyam",
            primaryColorHex = 0xFF4A0E17,
            secondaryColorHex = 0xFFFFD700
        ),
        WallpaperItem(
            id = "wp_3",
            title = LocalizedText("Lord Shiva Dhyanam in Himalayas", "కైలాస గిరిపై పరమేశ్వరుని ధ్యానం", "कैलाश शिव ध्यान", "கைலாய சிவன்", "ಕೈಲಾಸ ಶಿವ ಧ್ಯಾನ"),
            deity = LocalizedText("Lord Parama Shiva", "శ్రీ పరమశివుడు", "भगवान शिव", "சிவபெருமான்", "ಪರಮಶಿವ"),
            category = "Meditation & Peace",
            primaryColorHex = 0xFF102A43,
            secondaryColorHex = 0xFF90CAF9
        ),
        WallpaperItem(
            id = "wp_4",
            title = LocalizedText("Veera Anjaneya Sindhoora Roopa", "వీరాంజనేయ సింధూర రూపం", "वीर हनुमान", "வீர அனுமன்", "ವೀರ ಹನುಮಂತ"),
            deity = LocalizedText("Lord Hanuman", "శ్రీ వీరాంజనేయ స్వామి", "श्री हनुमान", "அனுமன்", "ಹನುಮಂತ"),
            category = "Protection & Courage",
            primaryColorHex = 0xFF5D1005,
            secondaryColorHex = 0xFFFF9800
        ),
        WallpaperItem(
            id = "wp_5",
            title = LocalizedText("Sri Krishna Divine Flute Melody", "శ్రీ వేణుగోపాల కృష్ణుని మురళీగానం", "श्री कृष्ण मुरली मनोहर", "ஸ்ரீ கிருஷ்ணர்", "ಶ್ರೀ ಕೃಷ್ಣ ಕೊಳಲು ನಾದ"),
            deity = LocalizedText("Lord Sri Krishna", "శ్రీ కృష్ణ పరమాత్మ", "भगवान कृष्ण", "கண்ணன்", "ಶ್ರೀ ಕೃಷ್ಣ"),
            category = "Bhakti & Anandam",
            primaryColorHex = 0xFF0A2540,
            secondaryColorHex = 0xFFFFE082
        )
    )

    private val sampleRingtones = listOf(
        RingtoneItem(
            id = "rt_1",
            title = LocalizedText("Venkateswara Suprabhatam Chime", "శ్రీ వేంకటేశ్వర సుప్రభాత ధ్వని", "वेंकटेश्वर सुप्रभातम्", "வெங்கடேஸ்வர சுப்ரபாதம்", "ವೆಂಕಟೇಶ್ವರ ಸುಪ್ರಭಾತ"),
            category = LocalizedText("Morning Stotram", "ఉదయ కాల స్తోత్రం", "प्रातः स्तोत्र", "காலை ஸ்லோகம்", "ಬೆಳಗಿನ ಸ್ತೋತ್ರ"),
            durationText = "0:45 min",
            description = LocalizedText("Kowsalya Supraja Rama sacred dawn opening chant", "కౌసల్యా సుప్రజా రామ దివ్య సుప్రభాత నాదం", "कौसल्या सुप्रजा राम...", "கௌசல்யா சுப்ரஜா ராம...", "ಕೌಸಲ್ಯಾ ಸುಪ್ರಜಾ ರಾಮ..."),
            deity = "Lord Venkateswara"
        ),
        RingtoneItem(
            id = "rt_2",
            title = LocalizedText("Sacred Temple Bell & Conch (Sankha)", "దివ్య దేవాలయ ఘంటానాదం & శంఖారావం", "दिव्य मंदिर घंटा एवं शंख ध्वनि", "கோவில் மணி & சங்கு நாதம்", "ದೇವಸ್ಥಾನದ ಘಂಟೆ & ಶಂಖ ನಾದ"),
            category = LocalizedText("Puja Bells & Instruments", "పూజా వాద్యాలు", "मंदिर वाद्य", "பூஜை வாத்தியம்", "ಪೂಜಾ ನಾದ"),
            durationText = "0:30 min",
            description = LocalizedText("Pure brass temple bell reverberation with sacred conch", "పవిత్ర ఇత్తడి గంటల నాదం మరియు శంఖధ్వని", "शुद्ध पीतल घंटी की पवित्र गूंज", "புனித கோவில் மணி ஓசை", "ಪವಿತ್ರ ಘಂಟಾನಾದ"),
            deity = "All Temples"
        ),
        RingtoneItem(
            id = "rt_3",
            title = LocalizedText("Maha Mrityunjaya Mantra Chants", "మహా మృత్యుంజయ మంత్ర నాదం", "महामृत्युंजय मंत्र", "மகா மிருத்யுஞ்சய மந்திரம்", "ಮಹಾ ಮೃತ್ಯುಂಜಯ ಮಂತ್ರ"),
            category = LocalizedText("Vedic Chants", "వేద మంత్రాలు", "वैदिक मंत्र", "வேத மந்திரம்", "ವೇದ ಮಂತ್ರ"),
            durationText = "0:52 min",
            description = LocalizedText("Powerful 108 peaceful vibrations for health & protection", "ఆరోగ్య రక్షక దివ్య మంత్ర జపం", "स्वास्थ्य एवं सुरक्षा हेतु पावन मंत्र", "ஆரோக்கியம் தரும் மந்திரம்", "ಆರೋಗ್ಯ ರಕ್ಷಕ ಮಂತ್ರ"),
            deity = "Lord Shiva"
        ),
        RingtoneItem(
            id = "rt_4",
            title = LocalizedText("Hanuman Chalisa Blissful Stanza", "హనుమాన్ చాలీసా మధుర స్వరాలు", "हनुमान चालीसा धुन", "அனுமன் சாலிசா", "ಹನುಮಾನ್ ಚಾಲೀಸಾ ಧ್ವನಿ"),
            category = LocalizedText("Devotional Bhajans", "భక్తి సంకీర్తనలు", "भक्ति भजन", "பக்தி பாடல்", "ಭಕ್ತಿ ಗೀತೆ"),
            durationText = "0:40 min",
            description = LocalizedText("Jai Hanuman Jnana Guna Sagara uplifting chorus", "జై హనుమాన్ జ్ఞాన గుణ సాగర మధుర గానం", "जय हनुमान ज्ञान गुन सागर...", "ஜெய் அனுமான் ஞான குண சாகர...", "ಜೈ ಹನುಮಾನ್ ಜ್ಞಾನ ಗುಣ ಸಾಗರ..."),
            deity = "Lord Hanuman"
        ),
        RingtoneItem(
            id = "rt_5",
            title = LocalizedText("Sri Lalitha Sahasranama Dhwani", "శ్రీ లలితా సహస్రనామ మంగళ నాదం", "ललिता सहस्रनाम", "லலிதா சகஸ்ரநாமம்", "ಲಲಿತಾ ಸಹಸ್ರನಾಮ"),
            category = LocalizedText("Devi Stotrams", "దేవీ స్తోత్రాలు", "देवी स्तोत्र", "தேவி ஸ்லோகம்", "ದೇವಿ ಸ್ತೋತ್ರ"),
            durationText = "0:48 min",
            description = LocalizedText("Srimata Sri Maharajni soothing divine opening rhythm", "శ్రీమాతా శ్రీమహారాజ్ఞీ దివ్య నామ సంకీర్తనం", "श्रीमाता श्रीमहाराज्ञी दिव्य ध्वनि", "ஸ்ரீ மாதா ஸ்ரீ மஹாராஜ்ஞீ...", "ಶ್ರೀಮಾತಾ ಶ್ರೀಮಹಾರಾಜ್ಞೀ..."),
            deity = "Goddess Lalitha"
        )
    )

    private val sampleStotrams = listOf(
        StotramItem(
            id = "st_1",
            title = LocalizedText("Sri Vishnu Sahasranama Stotram", "శ్రీ విష్ణు సహస్రనామ స్తోత్రం", "श्री विष्णु सहस्रनाम स्तोत्र", "ஸ்ரீ விஷ்ணு சகஸ்ரநாமம்", "ಶ್ರೀ ವಿಷ್ಣು ಸಹಸ್ರನಾಮ"),
            deity = LocalizedText("Lord Maha Vishnu", "శ్రీ మహా విష్ణువు", "भगवान विष्णु", "மகா விஷ்ணு", "ಮಹಾ ವಿಷ್ಣು"),
            versesCount = 108,
            description = LocalizedText("Thousand divine names of Vishnu delivered by Bhishma Pitamaha to Dharmaraja.", "భీష్ముడు ధర్మరాజుకు ఉపదేశించిన పరమ పవిత్రమైన విష్ణువు వేయి నామములు.", "भीष्म पितामह द्वारा उपदिष्ट भगवान विष्णु के हजार नाम।", "பீஷ்மர் அருளிய விஷ்ணுவின் ஆயிரம் திருநாமங்கள்.", "ಭೀಷ್ಮ ಪಿತಾಮಹರು ಉಪದೇಶಿಸಿದ ವಿಷ್ಣುವಿನ ಸಹಸ್ರ ನಾಮಗಳು.")
        ),
        StotramItem(
            id = "st_2",
            title = LocalizedText("Aditya Hrudaya Stotram", "ఆదిత్య హృదయ స్తోత్రం", "आदित्य हृदय स्तोत्र", "ஆதித்ய ஹிருதய ஸ்தோத்திரம்", "ಆದಿತ್ಯ ಹೃದಯ ಸ್ತೋತ್ರ"),
            deity = LocalizedText("Surya Bhagavan", "శ్రీ సూర్యనారాయణ స్వామి", "सूर्य देव", "சூரிய பகவான்", "ಸೂರ್ಯ ಭಗವಾನ್"),
            versesCount = 31,
            description = LocalizedText("Sage Agastya's supreme hymn to Lord Rama for courage and triumph in battle.", "శ్రీరామునికి అగస్త్య మహర్షి ఉపదేశించిన సర్వ శత్రు జయకారక సూర్య స్తోత్రం.", "अगस्त्य मुनि द्वारा श्री राम को उपदिष्ट विजय प्रदाता स्तोत्र।", "அகத்தியர் ராமருக்கு உபதேசித்த வெற்றி தரும் சூரிய துதி.", "ಅಗಸ್ತ್ಯ ಮುನಿಗಳು ಶ್ರೀರಾಮನಿಗೆ ಉಪದೇಶಿಸಿದ ವಿಜಯದಾಯಕ ಸ್ತೋತ್ರ.")
        ),
        StotramItem(
            id = "st_3",
            title = LocalizedText("Sri Venkateswara Ashtottara Shatanamavali", "శ్రీ వేంకటేశ్వర అష్టోత్తర శతనామావళి", "श्री वेंकटेश्वर अष्टोत्तर शतनामावली", "வெங்கடேஸ்வர அஷ்டோத்திரம்", "ವೆಂಕಟೇಶ್ವರ ಅಷ್ಟೋತ್ತರ"),
            deity = LocalizedText("Lord Venkateswara", "శ్రీ వేంకటేశ్వర స్వామి", "भगवान वेंकटेश्वर", "ஏழுமலையான்", "ವೆಂಕಟೇಶ್ವರ"),
            versesCount = 108,
            description = LocalizedText("108 divine names for daily archana and flower offerings to Lord Balaji.", "శ్రీ వేంకటేశ్వర స్వామికి నిత్య పూజా సమయమున సమర్పించే 108 దివ్య నామాలు.", "प्रतिदिन पुष्पार्चन हेतु 108 पावन नाम।", "தினசரி அர்ச்சனைக்குரிய 108 திருநாமங்கள்.", "ದೈನಂದಿನ ಪುಷ್ಪಾರ್ಚನೆಗಾಗಿ 108 ಪವಿತ್ರ ನಾಮಗಳು.")
        )
    )

    fun getDailyDeity(dayOfWeek: DayOfWeek): DailyDeity {
        return dailyDeities[dayOfWeek] ?: dailyDeities[DayOfWeek.SATURDAY]!!
    }

    fun getDailyVerse(index: Int = 0): DevotionalVerse {
        return sampleVerses[index % sampleVerses.size]
    }

    fun getAllVerses(): List<DevotionalVerse> = sampleVerses

    fun getAllWallpapers(): List<WallpaperItem> = sampleWallpapers

    fun getAllRingtones(): List<RingtoneItem> = sampleRingtones

    fun getAllStotrams(): List<StotramItem> = sampleStotrams
}
