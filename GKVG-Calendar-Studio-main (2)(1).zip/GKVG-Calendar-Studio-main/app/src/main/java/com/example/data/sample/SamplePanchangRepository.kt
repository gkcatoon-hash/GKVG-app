package com.example.data.sample

import com.example.data.model.LocalizedText
import com.example.data.model.PanchangData
import java.time.DayOfWeek
import java.time.LocalDate

object SamplePanchangRepository {

    private val samvatsaraList = listOf(
        LocalizedText("Śrī Krodhi Nāma Samvatsaram", "శ్రీ క్రోధి నామ సంవత్సరం", "श्री क्रोधी नाम संवत्सर", "ஸ்ரீ க்ரோதி நாம சம்வத்ஸரம்", "ಶ್ರೀ ಕ್ರೋಧಿ ನಾಮ ಸಂವತ್ಸರ")
    )

    private val ayanamList = listOf(
        LocalizedText("Dakshinayanam", "దక్షిణాయనం", "दक्षिणायन", "தக்ஷிணாயனம்", "ದಕ್ಷಿಣಾಯನ"),
        LocalizedText("Uttarayanam", "ఉత్తరాయణం", "उत्तरायण", "உத்தராயணம்", "ಉತ್ತರಾಯಣ")
    )

    private val ruthuList = listOf(
        LocalizedText("Varsha Rutu", "వర్ష ఋతువు", "वर्षा ऋतु", "வர்ஷ ருது", "ವರ್ಷ ಋತು"),
        LocalizedText("Sharad Rutu", "శరద్ ఋతువు", "शरद ऋतु", "சரத் ருது", "ಶರದ್ ಋತು"),
        LocalizedText("Hemanta Rutu", "హేమంత ఋతువు", "हेमन्त ऋतु", "ஹேமந்த ருது", "ಹೇಮಂತ ಋತು"),
        LocalizedText("Shishira Rutu", "శిశిర ఋతువు", "शिशिर ऋतु", "சிசிர ருது", "ಶಿಶಿರ ಋತು"),
        LocalizedText("Vasantha Rutu", "వసంత ఋతువు", "वसन्त ऋतु", "வசந்த ருது", "ವಸಂತ ಋತು"),
        LocalizedText("Greeshma Rutu", "గ్రీష్మ ఋతువు", "ग्रीष्म ऋतु", "க்ரீஷ்ம ருது", "ಗ್ರೀಷ್ಮ ಋತು")
    )

    private val masamList = listOf(
        LocalizedText("Chaitra Masam", "చైత్ర మాసం", "चैत्र मास", "சைத்ர மாஸம்", "ಚೈತ್ರ ಮಾಸ"),
        LocalizedText("Vaisakha Masam", "వైశాఖ మాసం", "वैशाख मास", "வைகாசி மாஸம்", "ವೈಶಾಖ ಮಾಸ"),
        LocalizedText("Jyeshtha Masam", "జ్యేష్ఠ మాసం", "ज्येष्ठ मास", "ஆனி மாஸம்", "ಜ್ಯೇಷ್ಠ ಮಾಸ"),
        LocalizedText("Ashadha Masam", "ఆషాఢ మాసం", "आषाढ़ मास", "ஆடி மாஸம்", "ಆಷಾಢ ಮಾಸ"),
        LocalizedText("Sravana Masam", "శ్రావణ మాసం", "श्रावण मास", "ஆவணி மாஸம்", "ಶ್ರಾವಣ ಮಾಸ"),
        LocalizedText("Bhadrapada Masam", "భాద్రపద మాసం", "भाद्रपद मास", "புரட்டாசி மாஸம்", "ಭಾದ್ರಪದ ಮಾಸ"),
        LocalizedText("Asviyuja Masam", "ఆశ్వయుజ మాసం", "आश्विन मास", "ஐப்பசி மாஸம்", "ಆಶ್ವಯುಜ ಮಾಸ"),
        LocalizedText("Karthika Masam", "కార్తీక మాసం", "कार्तिक मास", "கார்த்திகை மாஸம்", "ಕಾರ್ತಿಕ ಮಾಸ"),
        LocalizedText("Margasira Masam", "మార్గశిర మాసం", "मार्गशीर्ष मास", "மார்கழி மாஸம்", "ಮಾರ್ಗಶಿರ ಮಾಸ"),
        LocalizedText("Pushya Masam", "పుష్య మాసం", "पौष मास", "தை மாஸம்", "ಪುಷ್ಯ ಮಾಸ"),
        LocalizedText("Magha Masam", "మాఘ మాసం", "माघ मास", "மாசி மாஸம்", "ಮಾಘ ಮಾಸ"),
        LocalizedText("Phalguna Masam", "ఫాల్గుణ మాసం", "फाल्गुन मास", "பங்குனி மாஸம்", "ಫಾಲ್ಗುಣ ಮಾಸ")
    )

    private val tithiCycle = listOf(
        LocalizedText("Prathama (Padyami)", "పాడ్యమి (Prathama)", "प्रतिपदा", "பிரதமை", "ಪಾಡ್ಯಮಿ"),
        LocalizedText("Dvitiya (Vidiya)", "విదియ (Dvitiya)", "द्वितीया", "துவிதியை", "ಬಿದಿಗೆ"),
        LocalizedText("Tritiya (Thadiya)", "తదియ (Tritiya)", "तृतीया", "திருதியை", "ತದಿಗೆ"),
        LocalizedText("Chaturthi (Chavithi)", "చవితి (Chaturthi)", "चतुर्थी", "சதுர்த்தி", "ಚೌತಿ"),
        LocalizedText("Panchami", "పంచమి (Panchami)", "पंचमी", "பஞ்சமி", "ಪಂಚಮಿ"),
        LocalizedText("Shashthi", "షష్ఠి (Shashthi)", "षष्ठी", "சஷ்டி", "ಷಷ್ಠಿ"),
        LocalizedText("Saptami", "సప్తమి (Saptami)", "सप्तमी", "ஸப்தமி", "ಸಪ್ತಮಿ"),
        LocalizedText("Ashtami", "అష్టమి (Ashtami)", "अष्टमी", "அஷ்டமி", "ಅಷ್ಟಮಿ"),
        LocalizedText("Navami", "నవమి (Navami)", "नवमी", "நவமி", "ನವಮಿ"),
        LocalizedText("Dasami", "దశమి (Dasami)", "दशमी", "தசமி", "ದಶಮಿ"),
        LocalizedText("Ekadasi", "ఏకాదశి (Ekadasi)", "एकादशी", "ஏகாதசி", "ಏಕಾದಶಿ"),
        LocalizedText("Dvadasi", "ద్వాదశి (Dvadasi)", "द्वादशी", "துவாதசி", "ದ್ವಾದಶಿ"),
        LocalizedText("Trayodasi", "త్రయోదశి (Trayodasi)", "त्रयोदशी", "திரயோதசி", "ತ್ರಯೋದಶಿ"),
        LocalizedText("Chaturdasi", "చతుర్దశి (Chaturdasi)", "चतुर्दशी", "சதுர்த்தசி", "ಚತುರ್ದಶಿ"),
        LocalizedText("Pournami (Full Moon)", "పూర్ణిమ / పౌర్ణమి", "पूर्णिमा", "பௌர்ணமி", "ಹುಣ್ಣಿಮೆ"),
        LocalizedText("Amavasya (New Moon)", "అమావాస్య (Amavasya)", "अमावस्या", "அமாவாசை", "ಅಮಾವಾಸ್ಯೆ")
    )

    private val nakshatraCycle = listOf(
        LocalizedText("Ashwini", "అశ్విని", "अश्विनी", "அஸ்வினி", "ಅಶ್ವಿನಿ"),
        LocalizedText("Bharani", "భరణి", "भरणी", "பரணி", "ಭರಣಿ"),
        LocalizedText("Krittika", "కృత్తిక", "कृत्तिका", "கார்த்திகை", "ಕೃತ್ತಿಕಾ"),
        LocalizedText("Rohini", "రోహిణి", "रोहिणी", "ரோகிணி", "ರೋಹಿಣಿ"),
        LocalizedText("Mrigashira", "మృగశిర", "मृगशिरा", "மிருகசீரிஷம்", "ಮೃಗಶಿರ"),
        LocalizedText("Ardra", "ఆరుద్ర", "आर्द्रा", "திருவாதிரை", "ಆರ್ದ್ರ"),
        LocalizedText("Punarvasu", "పునర్వసు", "पुनर्वसु", "புனர்பூசம்", "ಪುನರ್ವಸು"),
        LocalizedText("Pushya", "పుష్యమి", "पुष्य", "பூசம்", "ಪುಷ್ಯ"),
        LocalizedText("Ashlesha", "ఆశ్లేష", "आश्लेषा", "ஆயில்யம்", "ಆಶ್ಲೇಷ"),
        LocalizedText("Magha", "మఖ", "मघा", "மகம்", "ಮಘ"),
        LocalizedText("Purva Phalguni", "పూర్వ ఫల్గుని (పుబ్బ)", "पूर्वाफाल्गुनी", "பூரம்", "ಪೂರ್ವ ಫಲ್ಗುಣಿ"),
        LocalizedText("Uttara Phalguni", "ఉత్తర ఫల్గుని (ఉత్తర)", "उत्तराफाल्गुनी", "உத்திரம்", "ಉತ್ತರ ಫಲ್ಗುಣಿ"),
        LocalizedText("Hasta", "హస్త", "हस्त", "ஹஸ்தம்", "ಹಸ್ತ"),
        LocalizedText("Chitra", "చిత్త", "चित्रा", "சித்திரை", "ಚಿತ್ತಾ"),
        LocalizedText("Swati", "స్వాతి", "स्वाति", "சுவாதி", "ಸ್ವಾತಿ"),
        LocalizedText("Vishakha", "విశాఖ", "विशाखा", "விசாகம்", "ವಿಶಾಖ"),
        LocalizedText("Anuradha", "అనూరాధ", "अनुराधा", "அனுஷம்", "ಅನೂರಾಧ"),
        LocalizedText("Jyeshtha", "జ్యేష్ఠ", "ज्येष्ठा", "கேட்டை", "ಜ್ಯೇಷ್ಠ"),
        LocalizedText("Mula", "మూల", "मूल", "மூலம்", "ಮೂಲ"),
        LocalizedText("Purva Ashadha", "పూర్వాషాఢ", "पूर्वाषाढ़ा", "பூராடம்", "ಪೂರ್ವಾಷಾಢ"),
        LocalizedText("Uttara Ashadha", "ఉత్తరాషాఢ", "उत्तराषाढ़ा", "உத்திராடம்", "ಉತ್ತರಾಷಾಢ"),
        LocalizedText("Shravana", "శ్రవణం", "श्रवण", "திருவோணம்", "ಶ್ರವಣ"),
        LocalizedText("Dhanishta", "ధనిష్ఠ", "धनिष्ठा", "அவிட்டம்", "ಧನಿಷ್ಠ"),
        LocalizedText("Shatabhisha", "శతభిషం", "शतभिषा", "சதயம்", "ಶತಭಿಷ"),
        LocalizedText("Purva Bhadrapada", "పూర్వాభాద్ర", "पूर्वाभाद्रपद", "பூரட்டாதி", "ಪೂರ್ವಾಭಾದ್ರ"),
        LocalizedText("Uttara Bhadrapada", "ఉత్తరాభాద్ర", "उत्तराभाद्रपद", "உத்திரட்டாதி", "ಉತ್ತರಾಭಾದ್ರ"),
        LocalizedText("Revati", "రేవతి", "रेवती", "ரேவதி", "ರೇವತಿ")
    )

    private fun getVaraName(dayOfWeek: DayOfWeek): LocalizedText {
        return when (dayOfWeek) {
            DayOfWeek.SUNDAY -> LocalizedText("Bhanu Vasaram (Sunday)", "ఆదివారం (Sunday)", "रविवार", "ஞாயிறு", "ಭಾನುವಾರ")
            DayOfWeek.MONDAY -> LocalizedText("Indu Vasaram (Monday)", "సోమవారం (Monday)", "सोमवार", "திங்கள்", "ಸೋಮವಾರ")
            DayOfWeek.TUESDAY -> LocalizedText("Bhauma Vasaram (Tuesday)", "మంగళవారం (Tuesday)", "मंगलवार", "செவ்வாய்", "ಮಂಗಳವಾರ")
            DayOfWeek.WEDNESDAY -> LocalizedText("Saumya Vasaram (Wednesday)", "బుధవారం (Wednesday)", "बुधवार", "புதன்", "ಬುಧವಾರ")
            DayOfWeek.THURSDAY -> LocalizedText("Guru Vasaram (Thursday)", "గురువారం (Thursday)", "गुरुवार", "வியாழன்", "ಗುರುವಾರ")
            DayOfWeek.FRIDAY -> LocalizedText("Bhrigu Vasaram (Friday)", "శుక్రవారం (Friday)", "शुक्रवार", "வெள்ளி", "ಶುಕ್ರವಾರ")
            DayOfWeek.SATURDAY -> LocalizedText("Sthira Vasaram (Saturday)", "శనివారం (Saturday)", "शनिवार", "சனி", "ಶನಿವಾರ")
        }
    }

    private fun getRahuKalamForDay(dayOfWeek: DayOfWeek): String {
        return when (dayOfWeek) {
            DayOfWeek.SUNDAY -> "04:30 PM - 06:00 PM"
            DayOfWeek.MONDAY -> "07:30 AM - 09:00 AM"
            DayOfWeek.TUESDAY -> "03:00 PM - 04:30 PM"
            DayOfWeek.WEDNESDAY -> "12:00 PM - 01:30 PM"
            DayOfWeek.THURSDAY -> "01:30 PM - 03:00 PM"
            DayOfWeek.FRIDAY -> "10:30 AM - 12:00 PM"
            DayOfWeek.SATURDAY -> "09:00 AM - 10:30 AM"
        }
    }

    private fun getYamaGandamForDay(dayOfWeek: DayOfWeek): String {
        return when (dayOfWeek) {
            DayOfWeek.SUNDAY -> "12:00 PM - 01:30 PM"
            DayOfWeek.MONDAY -> "10:30 AM - 12:00 PM"
            DayOfWeek.TUESDAY -> "09:00 AM - 10:30 AM"
            DayOfWeek.WEDNESDAY -> "07:30 AM - 09:00 AM"
            DayOfWeek.THURSDAY -> "06:00 AM - 07:30 AM"
            DayOfWeek.FRIDAY -> "03:00 PM - 04:30 PM"
            DayOfWeek.SATURDAY -> "01:30 PM - 03:00 PM"
        }
    }

    private fun getGulikaKalamForDay(dayOfWeek: DayOfWeek): String {
        return when (dayOfWeek) {
            DayOfWeek.SUNDAY -> "03:00 PM - 04:30 PM"
            DayOfWeek.MONDAY -> "01:30 PM - 03:00 PM"
            DayOfWeek.TUESDAY -> "12:00 PM - 01:30 PM"
            DayOfWeek.WEDNESDAY -> "10:30 AM - 12:00 PM"
            DayOfWeek.THURSDAY -> "09:00 AM - 10:30 AM"
            DayOfWeek.FRIDAY -> "07:30 AM - 09:00 AM"
            DayOfWeek.SATURDAY -> "06:00 AM - 07:30 AM"
        }
    }

    fun getPanchangForDate(date: LocalDate): PanchangData {
        val dayIndex = (date.dayOfYear + date.year) % 365
        val tithiIndex = (date.dayOfMonth - 1) % tithiCycle.size
        val nakshatraIndex = (dayIndex) % nakshatraCycle.size
        val paksha = if ((date.dayOfMonth % 30) < 15) {
            LocalizedText("Sukla Paksham (Waxing)", "శుక్ల పక్షం", "शुक्ल पक्ष", "சுக்ல பக்ஷம்", "ಶುಕ್ಲ ಪಕ್ಷ")
        } else {
            LocalizedText("Krishna Paksham (Waning)", "కృష్ణ పక్షం (బహుళ)", "कृष्ण पक्ष", "கிருஷ்ண பக்ஷம்", "ಕೃಷ್ಣ ಪಕ್ಷ")
        }

        val monthIndex = (date.monthValue + 3) % 12
        val masam = masamList[monthIndex]
        val ayanam = if (date.monthValue in 7..12) ayanamList[0] else ayanamList[1]
        val rutu = ruthuList[(date.monthValue / 2) % ruthuList.size]

        val specialFest = when {
            date.dayOfMonth == 15 -> LocalizedText("Pournami Puja / Special Vratam", "పౌర్ణమి పూజ / ప్రత్యేక వ్రతం", "पूर्णिमा पूजा", "பௌர்ணமி பூஜை", "ಹುಣ್ಣಿಮೆ ಪೂಜೆ")
            date.dayOfMonth == 11 -> LocalizedText("Ekadasi Vratam", "ఏకాదశి ఉపవాస వ్రతం", "एकादशी व्रत", "ஏகாதசி விரதம்", "ಏಕಾದಶಿ ವ್ರತ")
            date.dayOfWeek == DayOfWeek.SATURDAY -> LocalizedText("Sthira Vasaram — Lord Venkateswara Pooja", "శనివారం — శ్రీ వేంకటేశ్వర స్వామి ప్రత్యేక పూజ", "शनिवार विशेष पूजा", "சனிக்கிழமை சிறப்பு பூஜை", "ಶನಿವಾರ ವಿಶೇಷ ಪೂಜೆ")
            else -> null
        }

        return PanchangData(
            date = date,
            samvatsaram = samvatsaraList[0],
            ayanam = ayanam,
            rutu = rutu,
            masam = masam,
            paksham = paksha,
            tithi = tithiCycle[tithiIndex],
            tithiEndTime = "till 04:38 PM",
            nakshatram = nakshatraCycle[nakshatraIndex],
            nakshatramEndTime = "till 07:15 PM",
            yogam = LocalizedText("Brahma Yogam", "బ్రహ్మ యోగం", "ब्रह्म योग", "பிரம்ம யோகம்", "ಬ್ರಹ್ಮ ಯೋಗ"),
            karanam = LocalizedText("Balava Karanam", "బాలవ కరణం", "बालव करण", "பாலவ கரணம்", "ಬಾಲವ ಕರಣ"),
            vara = getVaraName(date.dayOfWeek),
            sunrise = "06:05 AM",
            sunset = "06:36 PM",
            moonrise = "01:20 PM",
            moonset = "01:45 AM",
            rahukalam = getRahuKalamForDay(date.dayOfWeek),
            yamagandam = getYamaGandamForDay(date.dayOfWeek),
            gulikakalam = getGulikaKalamForDay(date.dayOfWeek),
            durmuhurtham = "06:05 AM - 06:55 AM, 06:55 AM - 07:45 AM",
            varjyam = "11:15 AM - 12:50 PM",
            amritakalam = "08:30 PM - 10:05 PM",
            abhijitMuhurtham = "11:55 AM - 12:45 PM",
            specialFestivalToday = specialFest,
            isAuspiciousDay = true
        )
    }
}
