package com.example.data.model

data class WallpaperItem(
    val id: String,
    val title: LocalizedText,
    val deity: LocalizedText,
    val category: String,
    val resolution: String = "Ultra HD 4K",
    val primaryColorHex: Long = 0xFF1A365D,
    val secondaryColorHex: Long = 0xFFD4AF37
)

data class RingtoneItem(
    val id: String,
    val title: LocalizedText,
    val category: LocalizedText,
    val durationText: String,
    val description: LocalizedText,
    val deity: String
)

data class StotramItem(
    val id: String,
    val title: LocalizedText,
    val deity: LocalizedText,
    val versesCount: Int,
    val description: LocalizedText
)
