package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.PanchangLocation
import com.example.ui.theme.SacredGold300
import com.example.ui.theme.SacredGold400
import com.example.ui.theme.SacredGold500
import com.example.ui.theme.SleekCardSurface
import com.example.ui.theme.SleekNavyBackground
import com.example.ui.theme.SleekObsidianNav

@Composable
fun DevotionalHeader(
    currentLanguage: AppLanguage,
    currentLocation: PanchangLocation,
    onLanguageClick: () -> Unit,
    onLocationClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        SleekObsidianNav,
                        SleekNavyBackground
                    )
                )
            )
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("devotional_header")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sleek Top Branding
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Official GKVG Vector Logo
                Image(
                    painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.ic_gkvg_logo),
                    contentDescription = "GKVG Logo",
                    modifier = Modifier.size(42.dp)
                )
                
                Spacer(modifier = Modifier.width(10.dp))
                
                Column {
                    Text(
                        text = "GKVG CALENDAR",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = SacredGold500,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "PREMIUM DEVOTIONAL",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SacredGold500.copy(alpha = 0.8f),
                        letterSpacing = 1.8.sp
                    )
                }
            }

            // Quick Action Pills (Location & Language)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Location Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = SleekCardSurface,
                    border = BorderStroke(1.dp, SacredGold500.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onLocationClick() }
                        .testTag("header_location_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Location",
                            tint = SacredGold400,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = currentLocation.cityName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                }

                // Language Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = SleekCardSurface,
                    border = BorderStroke(1.dp, SacredGold500.copy(alpha = 0.45f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onLanguageClick() }
                        .testTag("header_language_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Language",
                            tint = SacredGold400,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = currentLanguage.nativeName.take(6),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SacredGold300
                        )
                    }
                }
            }
        }
    }
}

