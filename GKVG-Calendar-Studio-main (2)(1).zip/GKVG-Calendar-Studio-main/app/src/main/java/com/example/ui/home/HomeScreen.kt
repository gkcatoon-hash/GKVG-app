package com.example.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.PanchangData
import com.example.data.sample.SampleDevotionRepository
import com.example.ui.components.AuspiciousFestivalCard
import com.example.ui.components.DailyDeityCard
import com.example.ui.components.DailyVerseCard
import com.example.ui.components.GkvgWatermarkOverlay
import com.example.ui.components.PanchangCard
import com.example.ui.components.RasiPhalaluBannerCard
import com.example.ui.navigation.AppNavigationTab
import com.example.ui.theme.SacredGold300
import com.example.ui.theme.SacredGold400
import com.example.ui.theme.SacredGold500
import com.example.ui.theme.SleekCardSurface
import com.example.ui.theme.SleekNavyBackground
import com.example.ui.viewmodel.AppViewModel
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@Composable
fun HomeScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isPanchangExpanded by viewModel.isPanchangExpanded.collectAsState()
    val todayPanchang = viewModel.getTodayPanchang()
    val upcomingFestivals = viewModel.getUpcomingFestivals()
    val todayDeity = SampleDevotionRepository.getDailyDeity(LocalDate.now().dayOfWeek)
    val todayVerse = SampleDevotionRepository.getDailyVerse(LocalDate.now().dayOfYear)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(SleekNavyBackground)
    ) {
        // Subtle GKVG Watermark
        GkvgWatermarkOverlay(alpha = 0.035f)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("home_screen_content"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Sleek Today Summary Section with time greeting
            item {
                TodayDateSummary(
                    date = LocalDate.now(),
                    panchang = todayPanchang,
                    language = language,
                    onCalendarClick = { viewModel.selectTab(AppNavigationTab.CALENDAR) }
                )
            }

            // Today's Panchang Card (Sleek Dark Surface #003566 with Gold Accents)
            item {
                PanchangCard(
                    panchang = todayPanchang,
                    language = language,
                    isExpanded = isPanchangExpanded,
                    onToggleExpanded = { viewModel.togglePanchangExpanded() }
                )
            }

            // Prominent Rasi Phalalu (Horoscope) Entry Button & Carousel
            item {
                RasiPhalaluBannerCard(
                    language = language,
                    onOpenRasiModal = { sign -> viewModel.openRasiModal(sign) }
                )
            }

            // Today's Auspicious Festival Highlight (Gold Accent Surface)
            item {
                AuspiciousFestivalCard(
                    festivals = upcomingFestivals,
                    language = language,
                    onViewAllClick = { viewModel.selectTab(AppNavigationTab.FESTIVALS) }
                )
            }

            // Today's Deity Spotlight
            item {
                DailyDeityCard(
                    deity = todayDeity,
                    language = language
                )
            }

            // Daily Devotional Verse / Sloka Card
            item {
                DailyVerseCard(
                    verse = todayVerse,
                    language = language
                )
            }

            // GKVG Devotional Branding Footer
            item {
                GkvgDevotionalFooter(language = language)
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

private fun getTimeGreeting(language: AppLanguage): String {
    val hour = LocalTime.now().hour
    return when (hour) {
        in 5..11 -> when (language) {
            AppLanguage.TELUGU -> "శుభోదయం"
            AppLanguage.HINDI -> "शुभ प्रभात"
            AppLanguage.TAMIL -> "காலை வணக்கம்"
            AppLanguage.KANNADA -> "ಶುಭೋದಯ"
            AppLanguage.ENGLISH -> "Good Morning"
        }
        in 12..16 -> when (language) {
            AppLanguage.TELUGU -> "శుభ మధ్యాహ్నం"
            AppLanguage.HINDI -> "शुभ दोपहर"
            AppLanguage.TAMIL -> "மதிய வணக்கம்"
            AppLanguage.KANNADA -> "ಶುಭ ಅಪರಾಹ್ನ"
            AppLanguage.ENGLISH -> "Good Afternoon"
        }
        in 17..20 -> when (language) {
            AppLanguage.TELUGU -> "శుభ సాయంత్రం"
            AppLanguage.HINDI -> "शुभ संध्या"
            AppLanguage.TAMIL -> "மாலை வணக்கம்"
            AppLanguage.KANNADA -> "ಶುಭ ಸಂಜೆ"
            AppLanguage.ENGLISH -> "Good Evening"
        }
        else -> when (language) {
            AppLanguage.TELUGU -> "శుభ రాత్రి"
            AppLanguage.HINDI -> "शुभ रात्रि"
            AppLanguage.TAMIL -> "இரவு வணக்கம்"
            AppLanguage.KANNADA -> "ಶುಭ ರಾತ್ರಿ"
            AppLanguage.ENGLISH -> "Good Night"
        }
    }
}

@Composable
private fun TodayDateSummary(
    date: LocalDate,
    panchang: PanchangData,
    language: AppLanguage,
    onCalendarClick: () -> Unit
) {
    val greeting = getTimeGreeting(language)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 4.dp)
            .clickable { onCalendarClick() }
            .testTag("today_date_banner"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        Column(modifier = Modifier.weight(1f)) {
            // Time greeting tag
            Text(
                text = "✨ $greeting",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = SacredGold400,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = date.format(DateTimeFormatter.ofPattern("MMMM dd")),
                fontSize = 28.sp,
                fontWeight = FontWeight.Light,
                color = Color.White,
                lineHeight = 32.sp
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = "${date.format(DateTimeFormatter.ofPattern("EEEE"))} • ${panchang.samvatsaram.get(language)}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = SacredGold500
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Masam Badge
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = SleekCardSurface,
            border = BorderStroke(1.dp, SacredGold500.copy(alpha = 0.35f)),
            modifier = Modifier.padding(bottom = 2.dp)
        ) {
            Text(
                text = panchang.masam.get(language).uppercase(),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = SacredGold500,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
private fun GkvgDevotionalFooter(language: AppLanguage) {
    val footerBlessing = when (language) {
        AppLanguage.TELUGU -> "శ్రీ లక్ష్మీ వేంకటేశ్వర కటాక్ష సిద్ధిరస్తు • సర్వే జనాః సుఖినో భవంతు"
        AppLanguage.HINDI -> "श्री लक्ष्मी वेंकटेश्वर कृपा सदा बनी रहे • सर्वे भवन्तु सुखिनः"
        AppLanguage.TAMIL -> "ஸ்ரீ லக்ஷ்மி வெங்கடேஸ்வரர் அருள் நிலைக்கட்டும்"
        AppLanguage.KANNADA -> "ಶ್ರೀ ಲಕ್ಷ್ಮೀ ವೆಂಕಟೇಶ್ವರ ಕೃಪೆಯಿಂದ ಎಲ್ಲರಿಗೂ ಶುಭವಾಗಲಿ"
        AppLanguage.ENGLISH -> "May Sri Lakshmi Venkateswara bless you with peace and prosperity"
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SleekCardSurface.copy(alpha = 0.6f),
        border = BorderStroke(1.dp, SacredGold500.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_gkvg_diya),
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "GKVG CALENDAR",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = SacredGold400,
                    letterSpacing = 1.sp
                )
                Text(
                    text = footerBlessing,
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.75f),
                    lineHeight = 15.sp
                )
            }
        }
    }
}

