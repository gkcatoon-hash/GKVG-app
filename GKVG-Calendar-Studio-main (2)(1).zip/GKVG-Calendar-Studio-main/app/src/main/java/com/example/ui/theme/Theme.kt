package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.data.model.ThemeMode

private val DarkColorScheme = darkColorScheme(
    primary = SacredGold500,               // #D4AF37 Metallic Gold
    onPrimary = SleekNavyBackground,       // #001D3D Navy
    primaryContainer = SleekCardSurface,   // #003566 Midnight Blue
    onPrimaryContainer = SacredGold300,
    
    secondary = SacredGold400,             // Bright Gold
    onSecondary = SleekObsidianNav,
    secondaryContainer = SleekCardElevated,
    onSecondaryContainer = SacredGold100,
    
    tertiary = AuspiciousSaffron,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF662200),
    onTertiaryContainer = Color(0xFFFFDBCF),
    
    background = SleekNavyBackground,      // #001D3D
    onBackground = TextPrimaryDark,        // #F8FAFC
    surface = SleekCardSurface,            // #003566
    onSurface = TextPrimaryDark,
    surfaceVariant = SleekCardElevated,    // #004382
    onSurfaceVariant = TextSecondaryDark,  // #CBD5E1
    outline = Color(0x33D4AF37),           // #D4AF37/20 border
    outlineVariant = Color(0x1AD4AF37)
)

private val LightColorScheme = lightColorScheme(
    primary = SleekCardSurface,
    onPrimary = Color.White,
    primaryContainer = RoyalBlue50,
    onPrimaryContainer = SleekNavyBackground,
    
    secondary = SacredGold700,
    onSecondary = Color.White,
    secondaryContainer = SacredGold100,
    onSecondaryContainer = SacredGold900,
    
    tertiary = AuspiciousSaffron,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFEDE6),
    onTertiaryContainer = Color(0xFF5C2B05),
    
    background = SurfaceLight,
    onBackground = TextPrimaryLight,
    surface = SurfaceLightCard,
    onSurface = TextPrimaryLight,
    surfaceVariant = SurfaceLightCardElevated,
    onSurfaceVariant = TextSecondaryLight,
    outline = SurfaceLightBorder,
    outlineVariant = Color(0xFFD0DDEE)
)

@Composable
fun GKVGCalendarTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }

    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

