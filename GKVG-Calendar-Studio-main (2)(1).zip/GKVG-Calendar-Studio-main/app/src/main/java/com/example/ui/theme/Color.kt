package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GKVG Calendar - Sleek Interface Theme Palette

// Sleek Interface Core Midnight Blues
val SleekNavyBackground = Color(0xFF001D3D)     // Primary canvas bg #001D3D
val SleekObsidianNav = Color(0xFF000814)        // Bottom Nav / Deepest dark #000814
val SleekCardSurface = Color(0xFF003566)        // Card surface #003566
val SleekCardElevated = Color(0xFF004480)       // Elevated card surface
val SleekCardOverlay = Color(0x99003566)        // Semi-transparent card

// Sleek Metallic Gold (#D4AF37) & Variations
val SacredGold500 = Color(0xFFD4AF37)          // Core Sleek Gold #D4AF37
val SacredGold400 = Color(0xFFE5C158)          // Light Sleek Gold
val SacredGold300 = Color(0xFFF3D98A)          // Bright Sleek Gold
val SacredGold200 = Color(0xFFFAECC4)          // Pale Sleek Gold
val SacredGold100 = Color(0xFFFDF7E7)          // Shimmer Sleek Gold
val SacredGold600 = Color(0xFFBA9626)          // Rich Gold
val SacredGold700 = Color(0xFF9E7C16)          // Deep Gold
val SacredGold800 = Color(0xFF7A5F0C)          // Dark Accent Gold
val SacredGold900 = Color(0xFF4D3B03)          // Shadow Gold

// Sleek Navy Aliases for backward compatibility
val RoyalBlue900 = Color(0xFF000814)
val RoyalBlue800 = Color(0xFF001D3D)
val RoyalBlue700 = Color(0xFF002855)
val RoyalBlue600 = Color(0xFF003566)
val RoyalBlue500 = Color(0xFF004382)
val RoyalBlue400 = Color(0xFF0D5C9E)
val RoyalBlue300 = Color(0xFF2B78BF)
val RoyalBlue200 = Color(0xFF6DA5DF)
val RoyalBlue100 = Color(0xFFB8D5F6)
val RoyalBlue50 = Color(0xFFEDF5FD)

// Auspicious Saffron & Highlights
val AuspiciousSaffron = Color(0xFFFF7A18)
val SacredVermilion = Color(0xFFE63946)
val SacredKunkum = Color(0xFFD62246)
val SacredTulasiGreen = Color(0xFF2A9D8F)
val AuspiciousGreen = Color(0xFF38B000)

// Sleek Light Theme Surfaces
val SurfaceLight = Color(0xFFF3F7FC)
val SurfaceLightCard = Color(0xFFFFFFFF)
val SurfaceLightCardElevated = Color(0xFFE8EEF8)
val SurfaceLightBorder = Color(0xFFD0DDEE)
val TextPrimaryLight = Color(0xFF001D3D)
val TextSecondaryLight = Color(0xFF335C8D)
val TextMutedLight = Color(0xFF6B82A0)

// Sleek Dark Theme Surfaces (Sleek Interface Specification)
val SurfaceDark = Color(0xFF001D3D)
val SurfaceDarkCard = Color(0xFF003566)
val SurfaceDarkCardElevated = Color(0xFF004382)
val SurfaceDarkBorder = Color(0x40D4AF37) // 25% Gold border
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFFCBD5E1)
val TextMutedDark = Color(0xFF94A3B8)

// Specific Functional Muhurtham Colors
val RahuKalamRed = Color(0xFFEF4444)
val AmritaKalamGreen = Color(0xFF22C55E)
val YamaGandamOrange = Color(0xFFF97316)
val GulikaBlue = Color(0xFF38BDF8)

