package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.calendar.CalendarScreen
import com.example.ui.components.DevotionalHeader
import com.example.ui.components.LanguageSelectionDialog
import com.example.ui.components.LocationSelectionDialog
import com.example.ui.components.RasiPhalaluModal
import com.example.ui.devotion.DevotionScreen
import com.example.ui.festivals.FestivalsScreen
import com.example.ui.home.HomeScreen
import com.example.ui.navigation.AppNavigationTab
import com.example.ui.settings.SettingsScreen
import com.example.ui.splash.SplashScreen
import com.example.ui.theme.GKVGCalendarTheme
import com.example.ui.theme.RoyalBlue900
import com.example.ui.theme.SacredGold300
import com.example.ui.theme.SacredGold500
import com.example.ui.theme.SacredGold700
import com.example.ui.viewmodel.AppViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            
            GKVGCalendarTheme(themeMode = themeMode) {
                GKVGCalendarApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun GKVGCalendarApp(viewModel: AppViewModel) {
    val isSplashActive by viewModel.isSplashActive.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val currentLocation by viewModel.selectedLocation.collectAsState()
    val isRasiModalOpen by viewModel.isRasiModalOpen.collectAsState()
    val selectedRasiSign by viewModel.selectedRasiSign.collectAsState()
    val selectedHoroscopeTimeframe by viewModel.horoscopeTimeframe.collectAsState()
    val isLanguageDialogOpen by viewModel.isLanguageDialogOpen.collectAsState()
    val isLocationDialogOpen by viewModel.isLocationDialogOpen.collectAsState()

    AnimatedContent(
        targetState = isSplashActive,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "SplashToMainTransition"
    ) { showSplash ->
        if (showSplash) {
            SplashScreen(
                language = currentLanguage,
                onSplashFinished = { viewModel.dismissSplash() }
            )
        } else {
            // Modals & Dialogs
            if (isRasiModalOpen) {
                RasiPhalaluModal(
                    selectedSign = selectedRasiSign,
                    selectedTimeframe = selectedHoroscopeTimeframe,
                    language = currentLanguage,
                    onSelectSign = { viewModel.selectRasiSign(it) },
                    onSelectTimeframe = { viewModel.setHoroscopeTimeframe(it) },
                    onDismiss = { viewModel.closeRasiModal() }
                )
            }

            if (isLanguageDialogOpen) {
                LanguageSelectionDialog(
                    currentLanguage = currentLanguage,
                    onLanguageSelected = { viewModel.setLanguage(it) },
                    onDismiss = { viewModel.closeLanguageDialog() }
                )
            }

            if (isLocationDialogOpen) {
                LocationSelectionDialog(
                    currentLocation = currentLocation,
                    onLocationSelected = { viewModel.setLocation(it) },
                    onDismiss = { viewModel.closeLocationDialog() }
                )
            }

            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("gkvg_calendar_scaffold"),
                topBar = {
                    DevotionalHeader(
                        currentLanguage = currentLanguage,
                        currentLocation = currentLocation,
                        onLanguageClick = { viewModel.openLanguageDialog() },
                        onLocationClick = { viewModel.openLocationDialog() }
                    )
                },
                bottomBar = {
                    GKVGBottomNavigationBar(
                        currentTab = currentTab,
                        language = currentLanguage,
                        onTabSelect = { viewModel.selectTab(it) }
                    )
                },
                containerColor = MaterialTheme.colorScheme.background
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    AnimatedContent(
                        targetState = currentTab,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "ScreenTransition"
                    ) { tab ->
                        when (tab) {
                            AppNavigationTab.HOME -> HomeScreen(viewModel = viewModel)
                            AppNavigationTab.CALENDAR -> CalendarScreen(viewModel = viewModel)
                            AppNavigationTab.FESTIVALS -> FestivalsScreen(viewModel = viewModel)
                            AppNavigationTab.DEVOTION -> DevotionScreen(viewModel = viewModel)
                            AppNavigationTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GKVGBottomNavigationBar(
    currentTab: AppNavigationTab,
    language: com.example.data.model.AppLanguage,
    onTabSelect: (AppNavigationTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = com.example.ui.theme.SleekObsidianNav,
        border = BorderStroke(1.dp, SacredGold500.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        NavigationBar(
            containerColor = com.example.ui.theme.SleekObsidianNav,
            tonalElevation = 0.dp,
            modifier = Modifier
                .navigationBarsPadding()
                .testTag("gkvg_bottom_navigation")
        ) {
            AppNavigationTab.values().forEach { tab ->
                val isSelected = tab == currentTab
                val label = tab.getLabel(language)

                NavigationBarItem(
                    selected = isSelected,
                    onClick = { onTabSelect(tab) },
                    icon = {
                        Icon(
                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                            contentDescription = label,
                            tint = if (isSelected) SacredGold500 else Color.White.copy(alpha = 0.45f),
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = {
                        Text(
                            text = label,
                            fontSize = 10.5.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) SacredGold500 else Color.White.copy(alpha = 0.45f),
                            maxLines = 1
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = SacredGold500.copy(alpha = 0.18f),
                        selectedIconColor = SacredGold500,
                        unselectedIconColor = Color.White.copy(alpha = 0.45f),
                        selectedTextColor = SacredGold500,
                        unselectedTextColor = Color.White.copy(alpha = 0.45f)
                    ),
                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                )
            }
        }
    }
}


