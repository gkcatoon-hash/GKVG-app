package com.example.data.sample

import com.example.data.model.Festival
import com.example.data.model.FestivalCategory
import com.example.data.model.LocalizedText
import java.time.LocalDate

object SampleFestivalRepository {

    private val allFestivals = listOf(
        Festival(
            id = "ugadi",
            name = LocalizedText("Ugadi (Telugu New Year)", "ఉగాది (తెలుగు నూతన సంవత్సరం)", "उगादि", "யுகாதி", "ಯುಗಾದಿ"),
            date = LocalDate.of(2026, 3, 20),
            category = FestivalCategory.MAJOR,
            description = LocalizedText(
                "Celebration of the New Astronomical Year with Panchanga Sravanam and Ugadi Pachadi.",
                "కొత్త సంవత్సర ప్రారంభం, ఉగాది పచ్చడి మరియు పంచాంగ శ్రవణం.",
                "नव वर्ष का पावन उत्सव",
                "புத்தாண்டு கொண்டாட்டம்",
                "ಯುಗಾದಿ ಹಬ್ಬದ ಆಚರಣೆ"
            ),
            deityAssociated = "Lord Brahma & Vishnu"
        ),
        Festival(
            id = "rama_navami",
            name = LocalizedText("Sri Rama Navami", "శ్రీ రామ నవమి", "श्री राम नवमी", "ஸ்ரீ ராம நவமி", "ಶ್ರೀ ರಾಮ ನವಮಿ"),
            date = LocalDate.of(2026, 3, 28),
            category = FestivalCategory.MAJOR,
            description = LocalizedText(
                "Celebration of Lord Rama's appearance and Sri Sita Rama Kalyanam.",
                "శ్రీ సీతారాముల దివ్య కల్యాణ మహోత్సవం మరియు శ్రీరామ జయంతి.",
                "भगवान श्री राम का प्राकट्योत्सव",
                "ஸ்ரீ ராம பிரானின் அவதார தினம்",
                "ಶ್ರೀ ರಾಮ ನವಮಿ ಮಹೋತ್ಸವ"
            ),
            deityAssociated = "Lord Sri Rama"
        ),
        Festival(
            id = "hanuman_jayanti",
            name = LocalizedText("Hanumad Jayanti", "హనుమజ్జయంతి", "हनुमान जयंती", "ஹனுமத் ஜெயந்தி", "ಹನುಮ ಜಯಂತಿ"),
            date = LocalDate.of(2026, 4, 3),
            category = FestivalCategory.JAYANTI,
            description = LocalizedText(
                "Divine birth celebrations of Lord Hanuman with Sindhoora Pooja and Hanuman Chalisa.",
                "శ్రీ వీరాంజనేయ స్వామి జయంతి మరియు సింధూరార్చన పూజలు.",
                "संकटमोचन हनुमान जी की जयंती",
                "அனுமன் அவதார திருநாள்",
                "ಶ್ರೀ ಹನುಮ ಜಯಂತಿ"
            ),
            deityAssociated = "Lord Hanuman"
        ),
        Festival(
            id = "guru_purnima",
            name = LocalizedText("Guru Purnima (Vyasa Purnima)", "గురు పౌర్ణమి (వ్యాస పూర్ణిమ)", "गुरु पूर्णिमा", "குரு பூர்ணிமா", "ಗುರು ಪೂರ್ಣಿಮಾ"),
            date = LocalDate.of(2026, 7, 29),
            category = FestivalCategory.VRATAM,
            description = LocalizedText(
                "Honoring Sage Veda Vyasa and spiritual teachers with Guru Pooja.",
                "వేద వ్యాస మహర్షి జయంతి మరియు గురు పాదుకా పూజల సమయం.",
                "गुरु पूजन एवं वेदव्यास जयंती",
                "குருவின் திருவடி தொழும் திருநாள்",
                "ಗುರು ಪೂಜೆಯ ಪವಿತ್ರ ದಿನ"
            ),
            deityAssociated = "Sage Veda Vyasa & Sadguru"
        ),
        Festival(
            id = "varalakshmi_vratam",
            name = LocalizedText("Varalakshmi Vratam", "శ్రావణ వరలక్ష్మీ వ్రతం", "वरलक्ष्मी व्रत", "வரலட்சுமி விரதம்", "ವರಮಹಾಲಕ್ಷ್ಮಿ ವ್ರತ"),
            date = LocalDate.of(2026, 8, 21),
            category = FestivalCategory.VRATAM,
            description = LocalizedText(
                "Auspicious Friday worship of Goddess Lakshmi for family prosperity and health.",
                "శ్రావణ శుక్రవార మహాలక్ష్మీ విశేష పూజ మరియు తోరణ పూజ.",
                "माता महालक्ष्मी की विशेष कृपा प्राप्ति हेतु व्रत",
                "மகாலட்சுமி அருள்பெறும் விரதம்",
                "ವರಮಹಾಲಕ್ಷ್ಮಿ ಪೂಜೆ"
            ),
            deityAssociated = "Goddess Sri Mahalakshmi"
        ),
        Festival(
            id = "krishna_janmashtami",
            name = LocalizedText("Sri Krishna Janmashtami", "శ్రీ కృష్ణ జన్మాష్టమి (గోకులాష్టమి)", "श्री कृष्ण जन्माष्टमी", "கிருஷ்ண ஜெயந்தி", "ಶ್ರೀ ಕೃಷ್ಣ ಜನ್ಮಾಷ್ಟಮಿ"),
            date = LocalDate.of(2026, 9, 3),
            category = FestivalCategory.MAJOR,
            description = LocalizedText(
                "Celebration of Lord Krishna's divine birth with midnight prayers and butter offerings.",
                "శ్రీ బాలకృష్ణుని జన్మదిన మహోత్సవం మరియు ఉట్లోత్సవం.",
                "भगवान श्री कृष्ण का जन्मोत्सव",
                "ஸ்ரீ கண்ணன் அவதரித்த திருநாள்",
                "ಶ್ರೀ ಕೃಷ್ಣ ಜನ್ಮಾಷ್ಟಮಿ"
            ),
            deityAssociated = "Lord Sri Krishna"
        ),
        Festival(
            id = "vinayaka_chavithi",
            name = LocalizedText("Vinayaka Chavithi (Ganesh Chaturthi)", "వినాయక చవితి (గణేశ చతుర్థి)", "गणेश चतुर्थी", "விநாயகர் சதுர்த்தி", "ಗಣೇಶ ಚತುರ್ಥಿ"),
            date = LocalDate.of(2026, 9, 14),
            category = FestivalCategory.MAJOR,
            description = LocalizedText(
                "Worship of Lord Ganesha with 21 varieties of sacred leaves (Ekavimsati Patri Pooja).",
                "సిద్ధి వినాయక స్వామి వ్రతము మరియు ఏకవింశతి పత్ర పూజ.",
                "प्रथम पूज्य भगवान गणेश का महामहोत्सव",
                "விக்ன விநாயகர் பூஜை",
                "ಗಣೇಶ ಚೌತಿ ಪೂಜೆ"
            ),
            deityAssociated = "Lord Ganesha"
        ),
        Festival(
            id = "navaratri_starts",
            name = LocalizedText("Devi Sharannavaratri Starts (Kalasha Sthapana)", "శరన్నవరాత్రులు ప్రారంభం", "नवरात्रि घटस्थापना", "நவராத்திரி தொடக்கம்", "ನವರಾತ್ರಿ ಪ್ರಾರಂಭ"),
            date = LocalDate.of(2026, 10, 11),
            category = FestivalCategory.TEMPLE_EVENT,
            description = LocalizedText(
                "Nine days of Goddess Durga worship in nine divine Alankarams.",
                "శ్రీ జగన్మాత దుర్గా దేవి నవరాత్రుల ఘటస్థాపన మహోత్సవం.",
                "आदिशक्ति की नौ दिवसीय आराधना",
                "அன்னை பராசக்தி நவராத்திரி பூஜை",
                "ನವರಾತ್ರಿ ಮಹೋತ್ಸವ"
            ),
            deityAssociated = "Goddess Durga / Sri Raja Rajeshwari"
        ),
        Festival(
            id = "vijaya_dasami",
            name = LocalizedText("Vijaya Dasami / Dussehra", "విజయదశమి (దసరా)", "विजयादशमी / दशहरा", "விஜயதசமி", "ವಿಜಯದಶಮಿ"),
            date = LocalDate.of(2026, 10, 20),
            category = FestivalCategory.MAJOR,
            description = LocalizedText(
                "Celebration of good over evil, Shami Pooja, and Ayudha Pooja.",
                "శమీ పూజ, ఆయుధ పూజ మరియు విజయ సూచక మహోత్సవం.",
                "बुराई पर अच्छाई की विजय का प्रतीक",
                "வெற்றி தரும் விஜயதசமி",
                "ವಿಜಯದಶಮಿ ಹಬ್ಬ"
            ),
            deityAssociated = "Goddess Mahishasura Mardini"
        ),
        Festival(
            id = "deepavali",
            name = LocalizedText("Deepavali (Festival of Lights)", "దీపావళి లక్ష్మీ కుబేర పూజ", "दीपावली महालक्ष्मी पूजन", "தீபாவளி பண்டிகை", "ದೀಪಾವಳಿ ಹಬ್ಬ"),
            date = LocalDate.of(2026, 11, 8),
            category = FestivalCategory.MAJOR,
            description = LocalizedText(
                "Illumination with oil lamps and Sri Mahalakshmi-Kubera Dhanaprapti Pooja.",
                "దీపాల వెలుగులు మరియు శ్రీ మహాలక్ష్మి ధన పూజ.",
                "दीपावली महापर्व एवं लक्ष्मी पूजन",
                "திருவிளக்கு பூஜை மற்றும் தீபாவளி",
                "ದೀಪಾವಳಿ ಲಕ್ಷ್ಮೀ ಪೂಜೆ"
            ),
            deityAssociated = "Goddess Lakshmi & Lord Kubera"
        ),
        Festival(
            id = "karthika_pournami",
            name = LocalizedText("Karthika Pournami / Jwala Thoranam", "కార్తీక పౌర్ణమి / జ్వాలాతోరణం", "कार्तिक पूर्णिमा", "கார்த்திகை தீபம்", "ಕಾರ್ತಿಕ ಹುಣ್ಣಿಮೆ"),
            date = LocalDate.of(2026, 11, 24),
            category = FestivalCategory.VRATAM,
            description = LocalizedText(
                "Lighting 365 wicks, Kedareswara Vratam, and Lord Shiva Linga Abhishekam.",
                "365 వత్తుల దీపారాధన, కేదారేశ్వర వ్రతం మరియు శివారాధన.",
                "देव दीपावली एवं कार्तिक पूर्णिमा स्नान",
                "திருவண்ணாமலை கார்த்திகை தீபம்",
                "ಕಾರ್ತಿಕ ದೀಪೋತ್ಸವ"
            ),
            deityAssociated = "Lord Shiva & Lord Vishnu"
        ),
        Festival(
            id = "vaikuntha_ekadasi",
            name = LocalizedText("Vaikuntha Ekadasi (Mukkoti Ekadasi)", "వైకుంఠ ఏకాదశి (ముక్కోటి ఏకాదశి)", "वैकुंठ एकादशी", "வைகுண்ட ஏகாதசி", "ವೈಕುಂಠ ಏಕಾದಶಿ"),
            date = LocalDate.of(2026, 12, 20),
            category = FestivalCategory.TEMPLE_EVENT,
            description = LocalizedText(
                "Opening of Uttaradwara / Vaikuntha Dwara Darshanam in Vishnu temples.",
                "వైకుంఠ ద్వార దర్శనం మరియు మహావిష్ణువు అనుగ్రహ ప్రాప్తి.",
                "वैकुंठ द्वार दर्शन एवं मोक्ष एकादशी",
                "பரமபத வாசல் திறப்பு வைபவம்",
                "ವೈಕುಂಠ ದ್ವಾರ ದರ್ಶನ"
            ),
            deityAssociated = "Lord Sri Maha Vishnu / Venkateswara"
        ),
        Festival(
            id = "makara_sankranti",
            name = LocalizedText("Makara Sankranti / Pongal", "మకర సంక్రాంతి (పెద్ద పండుగ)", "मकर संक्रांति", "மகர சங்கராந்தி / பொங்கல்", "ಮಕರ ಸಂಕ್ರಾಂತಿ"),
            date = LocalDate.of(2026, 1, 14),
            category = FestivalCategory.MAJOR,
            description = LocalizedText(
                "Sun enters Makara Rasi, marking Uttarayanam start with Bhogi, Sankranti, Kanuma.",
                "సూర్యుని ఉత్తరాయణ పుణ్యకాల ప్రవేశం, ధాన్య లక్ష్మి పూజ.",
                "सूर्य का मकर राशि में प्रवेश एवं उत्तरायण प्रारंभ",
                "சூரிய பகவான் வழிபாடு மற்றும் பொங்கல்",
                "ಸುಗ್ಗಿ ಹಬ್ಬ ಸಂಕ್ರಾಂತಿ"
            ),
            deityAssociated = "Surya Bhagavan"
        ),
        Festival(
            id = "maha_shivaratri",
            name = LocalizedText("Maha Shivaratri", "మహా శివరాత్రి", "महाशिवरात्रि", "மகா சிவராத்திரி", "ಮಹಾ ಶಿವರಾತ್ರಿ"),
            date = LocalDate.of(2026, 2, 15),
            category = FestivalCategory.MAJOR,
            description = LocalizedText(
                "Night-long vigil (Jagaran), Lingodbhava Kalam prayers, and Rudrabhishekam.",
                "మహా లింగోద్భవ కాల రుద్రాభిషేకము మరియు రాత్రి జాగరణ.",
                "भगवान शिव की महाआराधना एवं जागरण",
                "சிவபெருமான் மகா சிவராத்திரி திருவிழா",
                "ಮಹಾ ಶಿವರಾತ್ರಿ ಜಾಗರಣೆ"
            ),
            deityAssociated = "Lord Parama Shiva"
        )
    )

    fun getAllFestivals(): List<Festival> = allFestivals

    fun getFestivalsForMonth(month: Int, year: Int): List<Festival> {
        return allFestivals.filter { it.date.monthValue == month }
    }

    fun getFestivalsForDate(date: LocalDate): List<Festival> {
        return allFestivals.filter { it.date == date }
    }

    fun getUpcomingFestivals(from: LocalDate, limit: Int = 4): List<Festival> {
        val sorted = allFestivals.sortedBy { it.date }
        val upcoming = sorted.filter { !it.date.isBefore(from) }
        return if (upcoming.isNotEmpty()) upcoming.take(limit) else sorted.take(limit)
    }
}
