package com.example.data.model

import java.time.LocalDate

enum class FestivalCategory(
    val englishTitle: String,
    val teluguTitle: String
) {
    ALL("All Events", "అన్నీ"),
    MAJOR("Major Festivals", "ముఖ్య పండుగలు"),
    VRATAM("Vratams & Pujas", "వ్రతాలు & పూజలు"),
    JAYANTI("Jayantis & Avatars", "జయంతి & అవతారాలు"),
    TEMPLE_EVENT("Temple Events", "దేవాలయ ఉత్సవాలు");

    fun getLabel(language: AppLanguage): String {
        return when (language) {
            AppLanguage.TELUGU -> teluguTitle
            else -> englishTitle
        }
    }
}

data class Festival(
    val id: String,
    val name: LocalizedText,
    val date: LocalDate,
    val category: FestivalCategory,
    val description: LocalizedText,
    val deityAssociated: String,
    val ritualHighlights: LocalizedText? = null
)

