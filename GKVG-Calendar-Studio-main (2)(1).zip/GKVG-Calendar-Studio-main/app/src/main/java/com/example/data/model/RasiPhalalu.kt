package com.example.data.model

enum class ZodiacSign(
    val englishName: String,
    val teluguName: String,
    val hindiName: String,
    val tamilName: String,
    val kannadaName: String,
    val symbolEmoji: String,
    val dateSpan: String
) {
    MESHA("Aries", "మేషం (Mesham)", "मेष", "மேஷம்", "ಮೇಷ", "♈", "Mar 21 - Apr 19"),
    VRISHABHA("Taurus", "వృషభం (Vrishabham)", "वृषभ", "ரிஷபம்", "ವೃಷಭ", "♉", "Apr 20 - May 20"),
    MITHUNA("Gemini", "మిథునం (Mithunam)", "मिथुन", "மிதுனம்", "ಮಿಥುನ", "♊", "May 21 - Jun 20"),
    KARKATAKA("Cancer", "కర్కాటకం (Karkatakam)", "कर्क", "கடகம்", "ಕರ್ಕಾಟಕ", "♋", "Jun 21 - Jul 22"),
    SIMHA("Leo", "సింహం (Simham)", "सिंह", "சிம்மம்", "ಸಿಂಹ", "♌", "Jul 23 - Aug 22"),
    KANYA("Virgo", "కన్య (Kanya)", "कन्या", "கன்னி", "ಕನ್ಯಾ", "♍", "Aug 23 - Sep 22"),
    TULA("Libra", "తుల (Tula)", "तुला", "துலாம்", "ತುಲಾ", "♎", "Sep 23 - Oct 22"),
    VRISCHIKA("Scorpio", "వృశ్చికం (Vrischikam)", "वृश्चिक", "விருச்சிகம்", "ವೃಶ್ಚಿಕ", "♏", "Oct 23 - Nov 21"),
    DHANUSU("Sagittarius", "ధనుస్సు (Dhanusu)", "धनु", "தனுசு", "ಧನುಸ್ಸು", "♐", "Nov 22 - Dec 21"),
    MAKARA("Capricorn", "మకరం (Makaram)", "मकर", "மகரம்", "ಮಕರ", "♑", "Dec 22 - Jan 19"),
    KUMBHA("Aquarius", "కుంభం (Kumbham)", "कुंभ", "கும்பம்", "ಕುಂಭ", "♒", "Jan 20 - Feb 18"),
    MEENA("Pisces", "మీనం (Meenam)", "मीन", "மீனம்", "ಮೀನ", "♓", "Feb 19 - Mar 20");

    fun getDisplayName(language: AppLanguage): String {
        return when (language) {
            AppLanguage.TELUGU -> teluguName
            AppLanguage.HINDI -> "$hindiName ($englishName)"
            AppLanguage.TAMIL -> "$tamilName ($englishName)"
            AppLanguage.KANNADA -> "$kannadaName ($englishName)"
            AppLanguage.ENGLISH -> "$englishName ($teluguName)"
        }
    }
}

enum class HoroscopeTimeframe(val title: String) {
    TODAY("Today"),
    WEEK("This Week"),
    MONTH("This Month")
}

data class RasiPhalalu(
    val sign: ZodiacSign,
    val rulingPlanet: LocalizedText,
    val luckyColor: LocalizedText,
    val luckyNumber: String,
    val todayPrediction: LocalizedText,
    val weekPrediction: LocalizedText,
    val monthPrediction: LocalizedText,
    val remedy: LocalizedText
)
