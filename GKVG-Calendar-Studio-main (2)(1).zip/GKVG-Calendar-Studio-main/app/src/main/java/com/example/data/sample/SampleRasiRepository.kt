package com.example.data.sample

import com.example.data.model.LocalizedText
import com.example.data.model.RasiPhalalu
import com.example.data.model.ZodiacSign

object SampleRasiRepository {

    private val allRasiData = listOf(
        RasiPhalalu(
            sign = ZodiacSign.MESHA,
            rulingPlanet = LocalizedText("Mars (Kuja)", "కుజుడు", "मंगल", "செவ்வாய்", "ಕುಜ"),
            luckyColor = LocalizedText("Red & Saffron", "ఎరుపు, సింధూరం", "लाल", "சிகப்பு", "ಕೆಂಪು"),
            luckyNumber = "9, 1, 6",
            todayPrediction = LocalizedText(
                "Energy is high. Pending tasks will see sudden breakthrough. Financial gains through business travel are indicated.",
                "ఉత్సాహంతో కూడిన దినం. వ్యాపార పనులలో ప్రగతి లభిస్తుంది. ధనలాభం మరియు బంధువుల మద్దతు లభిస్తుంది.",
                "उत्साह भरा दिन रहेगा। रुके हुए कार्य पूरे होंगे।",
                "ஆற்றல் நிறைந்த நாள். சுப காரியங்கள் கைகூடும்.",
                "ಉತ್ಸಾಹದ ದಿನ. ಬಾಕಿ ಉಳಿದ ಕೆಲಸಗಳು ಪೂರ್ಣಗೊಳ್ಳುತ್ತವೆ."
            ),
            weekPrediction = LocalizedText(
                "Favorable week for career expansion. Health stays resilient. Maintain calm communication in family matters.",
                "ఈ వారం ఉద్యోగంలో అనుకూలత, నూతన బాధ్యతలు చేపడతారు. కుటుంబంలో సంతోష వాతావరణం నెలకొంటుంది.",
                "करियर के लिए शुभ सप्ताह।",
                "தொழிலில் முன்னேற்றம் ஏற்படும்.",
                "ವೃತ್ತಿಜೀವನದಲ್ಲಿ ಪ್ರಗತಿ ಕಂಡುಬರುತ್ತದೆ."
            ),
            monthPrediction = LocalizedText(
                "Significant planetary support for property matters and investments. Spiritual trips will bring immense peace.",
                "ఈ నెల ఆస్తి విషయాలలో శుభ ఫలితాలు, తీర్థయాత్రల యోగం కలదు.",
                "संपत्ति एवं निवेश में सफलता।",
                "சொத்து சேர்க்கை மற்றும் ஆன்மீக பயணம் அமையும்.",
                "ಆಸ್ತಿ ವಿಷಯಗಳಲ್ಲಿ ಶುಭ ಫಲ."
            ),
            remedy = LocalizedText(
                "Chant Sri Hanuman Chalisa or offer red flowers to Lord Murugan.",
                "శ్రీ హనుమాన్ చాలీసా పఠించండి, స్వామికి సింధూర సమర్పణ చేయండి.",
                "हनुमान चालीसा का पाठ करें।",
                "அனுமன் வழிபாடு நன்மை தரும்.",
                "ಶ್ರೀ ಹನುಮಾನ್ ಚಾಲೀಸಾ ಪಠಿಸಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.VRISHABHA,
            rulingPlanet = LocalizedText("Venus (Shukra)", "శుక్రుడు", "शुक्र", "சுக்கிரன்", "ಶುಕ್ರ"),
            luckyColor = LocalizedText("White & Cream", "తెలుపు, లేత పసుపు", "सफेद", "வெள்ளை", "ಬಿಳಿ"),
            luckyNumber = "6, 5, 8",
            todayPrediction = LocalizedText(
                "Peaceful day with artistic inspiration. Financial stability improves. Good news from distant relatives.",
                "ప్రశాంతమైన దినం. కళారంగం, వ్యాపార రంగాల వారికి ధనలాభం. శుభవార్తలు వింటారు.",
                "दिन शांतिपूर्ण एवं लाभकारी रहेगा।",
                "மன அமைதியும் சுப செய்தியும் கிடைக்கும்.",
                "ಮನಸ್ಸಿಗೆ ನೆಮ್ಮದಿ ಮತ್ತು ಧನಲಾಭ."
            ),
            weekPrediction = LocalizedText(
                "Progress in creative and domestic projects. Excellent time for shopping and home renovation.",
                "గృహోపకరణాలు కొనుగోలు చేస్తారు. బంధుమిత్రుల కలయిక ఆనందాన్ని ఇస్తుంది.",
                "घर-परिवार में आनंद का वातावरण।",
                "குடும்பத்தில் மகிழ்ச்சி நிலவும்.",
                "ಕುಟುಂಬದಲ್ಲಿ ಸಂತೋಷದ ವಾತಾವರಣ."
            ),
            monthPrediction = LocalizedText(
                "Steady financial growth. Strategic alliances will yield long-term dividends.",
                "ఆర్థికంగా నిలకడ ఏర్పడుతుంది. నూతన పెట్టుబడులు లాభిస్తాయి.",
                "आर्थिक स्थिति सुदृढ़ होगी।",
                "நிதி நிலைமை சீராகும்.",
                "ಆರ್ಥಿಕ ಪರಿಸ್ಥಿತಿ ಉತ್ತಮಗೊಳ್ಳಲಿದೆ."
            ),
            remedy = LocalizedText(
                "Offer white lotus or milk sweet to Goddess Mahalakshmi on Friday.",
                "శుక్రవారం మహాలక్ష్మికి పాయసం లేదా తెల్లని పుష్పాలు సమర్పించండి.",
                "महालक्ष्मी की आराधना करें।",
                "மகாலட்சுமி தாயாரை வழிபடவும்.",
                "ಮಹಾಲಕ್ಷ್ಮಿ ಪೂಜೆ ಮಾಡಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.MITHUNA,
            rulingPlanet = LocalizedText("Mercury (Budha)", "బుధుడు", "बुध", "புதன்", "ಬುಧ"),
            luckyColor = LocalizedText("Emerald Green", "ఆకుపచ్చ (గ్రీన్)", "हरा", "பச்சை", "ಹಸಿರು"),
            luckyNumber = "5, 3, 1",
            todayPrediction = LocalizedText(
                "Sharp intellect leads to swift problem-solving. Communications and trade negotiations will succeed.",
                "సమయస్ఫూర్తితో సమస్యలను పరిష్కరిస్తారు. విద్యా, వ్యాపార విషయాలలో విజయం.",
                "बुद्धिमानी से सफलता प्राप्त होगी।",
                "புத்திசாலித்தனத்தால் காரிய வெற்றி.",
                "ಬುದ್ಧಿವಂತಿಕೆಯಿಂದ ಕೆಲಸಗಳಲ್ಲಿ ಯಶಸ್ಸು."
            ),
            weekPrediction = LocalizedText(
                "Travel for educational or business ventures proves fruitful. Networking brings exciting opportunities.",
                "ప్రయాణాలు లాభిస్తాయి. నూతన పరిచయాలు భవిష్యత్తుకు ఉపకరిస్తాయి.",
                "व्यापारिक यात्राएं लाभकारी सिद्ध होंगी।",
                "பயணங்கள் மூலம் ஆதாயம் கிடைக்கும்.",
                "ಪ್ರಯಾಣದಿಂದ ಲಾಭ ದೊರೆಯಲಿದೆ."
            ),
            monthPrediction = LocalizedText(
                "Outstanding month for career development and competitive examinations.",
                "ఉద్యోగంలో గుర్తింపు, నూతన ఆలోచనలకు ప్రశంసలు లభిస్తాయి.",
                "प्रतियोगी परीक्षाओं में सफलता के योग।",
                "போட்டித் தேர்வுகளில் வெற்றி வாய்ப்பு.",
                "ಉದ್ಯೋಗದಲ್ಲಿ ಹೊಸ ಅವಕಾಶಗಳು."
            ),
            remedy = LocalizedText(
                "Chant Vishnu Sahasranamam and feed green grass to cows (Go-Seva).",
                "శ్రీ విష్ణు సహస్రనామ పారాయణ మరియు గోసేవ చేయండి.",
                "विष्णु सहस्रनाम का पाठ करें।",
                "விஷ்ணு சகஸ்ரநாமம் பாராயணம் செய்யவும்.",
                "ವಿಷ್ಣು ಸಹಸ್ರನಾಮ ಪಠಿಸಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.KARKATAKA,
            rulingPlanet = LocalizedText("Moon (Chandra)", "చంద్రుడు", "चंद्र", "சந்திரன்", "ಚಂದ್ರ"),
            luckyColor = LocalizedText("Pearl Silver & White", "వెండి రంగు, తెలుపు", "सफेद", "முத்து நிறம்", "ಬೆಳ್ಳಿ ಬಣ್ಣ"),
            luckyNumber = "2, 7, 4",
            todayPrediction = LocalizedText(
                "Emotional clarity and familial warmth. Mother's blessings bring auspicious fortune.",
                "మాతృమూర్తి ఆశీస్సులు లభిస్తాయి. మానసిక ప్రశాంతత, దైవ దర్శన యోగం.",
                "माता का आशीर्वाद एवं मानसिक शांति।",
                "தாயாரின் ஆசி கிடைக்கும்.",
                "ತಾಯಿಯ ಆಶೀರ್ವಾದ ಮತ್ತು ಮನಶಾಂತಿ."
            ),
            weekPrediction = LocalizedText(
                "Intuition guides financial decisions accurately. Cherish serene family gatherings.",
                "ఆలోచించి తీసుకునే నిర్ణయాలు సత్ఫలితాలనిస్తాయి. ఇంటా బయటా అనుకూలత.",
                "पारिवारिक जीवन में मधुरता।",
                "குடும்ப ஒற்றுமை மேலோங்கும்.",
                "ಕುಟುಂಬದೊಂದಿಗೆ ಸಂತೋಷದ ಕ್ಷಣಗಳು."
            ),
            monthPrediction = LocalizedText(
                "High spiritual inclinations. Pilgrimages to holy rivers and coastal shrines indicated.",
                "పుణ్యక్షేత్ర దర్శనాలు, ఆధ్యాత్మిక సాధనలకు అనుకూలమైన మాసం.",
                "तीर्थ यात्रा के शुभ योग।",
                "புண்ணிய ஸ்தல தரிசனம் அமையும்.",
                "ಪುಣ್ಯಕ್ಷೇತ್ರಗಳ ದರ್ಶನ ಭಾಗ್ಯ."
            ),
            remedy = LocalizedText(
                "Offer milk Abhishekam to Lord Shiva on Monday mornings.",
                "సోమవారం శివునికి పాలాభిషేకం చేయండి, శివ పంచాక్షరి జపించండి.",
                "भगवान शिव को दुग्धाभिषेक करें।",
                "சிவபெருமானுக்கு பாலாபிஷேகம் செய்யவும்.",
                "ಶಿವಲಿಂಗಕ್ಕೆ ಹಾಲು ಅಭಿಷೇಕ ಮಾಡಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.SIMHA,
            rulingPlanet = LocalizedText("Sun (Surya)", "సూర్యుడు", "सूर्य", "சூரியன்", "ಸೂರ್ಯ"),
            luckyColor = LocalizedText("Golden Orange & Ruby", "బంగారు వర్ణం, కాషాయం", "नारंगी", "தங்க நிறம்", "ಚಿನ್ನದ ಬಣ್ಣ"),
            luckyNumber = "1, 4, 9",
            todayPrediction = LocalizedText(
                "Leadership qualities shine brightly. Respect from authorities and colleagues will elevate your morale.",
                "అధికారుల మన్ననలు పొందుతారు. పట్టుదలతో పనులు పూర్తి చేస్తారు.",
                "नेतृत्व क्षमता में वृद्धि एवं सम्मान।",
                "தலைமைப் பண்பு சிறக்கும். மரியாதை கூடும்.",
                "ನಾಯಕತ್ವ ಗುಣಗಳು ಮೆಚ್ಚುಗೆ ಪಡೆಯುತ್ತವೆ."
            ),
            weekPrediction = LocalizedText(
                "Victorious week over competitors. Official recognitions or awards on the horizon.",
                "పోటీల్లో విజయం సాధిస్తారు. సమాజంలో గౌరవ ప్రతిష్టలు పెరుగుతాయి.",
                "प्रतिद्वंद्वियों पर विजय प्राप्त होगी।",
                "தொழிலில் வெற்றி கிடைக்கும்.",
                "ಸ್ಪರ್ಧೆಗಳಲ್ಲಿ ಗೆಲುವು ನಿಮ್ಮದಾಗುತ್ತದೆ."
            ),
            monthPrediction = LocalizedText(
                "Royal progression in professional ventures. Great fortune in governmental projects.",
                "ఉద్యోగంలో పదోన్నతి, ప్రభుత్వ పరమైన పనులలో అనుకూలత.",
                "प्रशासनिक कार्यों में सफलता।",
                "அரசு வழியில் அனுகூலம் உண்டாகும்.",
                "ಸರ್ಕಾರಿ ಕೆಲಸಗಳಲ್ಲಿ ಶುಭ ಫಲ."
            ),
            remedy = LocalizedText(
                "Offer Arghya (water) to Surya Bhagavan at sunrise chanting Aditya Hrudayam.",
                "సూర్యోదయం వేళ సూర్య నమస్కారాలు, ఆదిత్య హృదయ స్తోత్ర పఠనం చేయండి.",
                "आदित्य हृदय स्तोत्र का पाठ करें।",
                "சூரிய நமஸ்காரம் மற்றும் ஆதித்ய ஹிருதயம் நலம் தரும்.",
                "ಆದಿತ್ಯ ಹೃದಯ ಸ್ತೋತ್ರ ಪಠಿಸಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.KANYA,
            rulingPlanet = LocalizedText("Mercury (Budha)", "బుధుడు", "बुध", "புதன்", "ಬುಧ"),
            luckyColor = LocalizedText("Pistachio Green & Yellow", "లేత ఆకుపచ్చ, పసుపు", "हल्का हरा", "பச்சை", "ಹಸಿರು"),
            luckyNumber = "5, 6, 2",
            todayPrediction = LocalizedText(
                "Meticulous planning brings efficiency. Analytical decisions yield high returns.",
                "ప్రణాళికాబద్ధంగా వ్యవహరించి విజయం సాధిస్తారు. ఖర్చులు అదుపులో ఉంటాయి.",
                "योजनाबद्ध कार्यों में सफलता मिलेगी।",
                "திட்டமிட்ட காரியங்கள் வெற்றிகரமாக முடியும்.",
                "ಯೋಜನಾಬದ್ಧ ಕೆಲಸಗಳಲ್ಲಿ ಸಫಲತೆ."
            ),
            weekPrediction = LocalizedText(
                "Health improvements and positive lifestyle habits blossom this week.",
                "ఆరోగ్యం మెరుగుపడుతుంది. విజ్ఞానదాయక చర్చల్లో పాల్గొంటారు.",
                "स्वास्थ्य में सुधार होगा।",
                "உடல் ஆரோக்கியம் மேம்படும்.",
                "ಆರೋಗ್ಯದಲ್ಲಿ ಚೇತರಿಕೆ ಕಂಡುಬರುತ್ತದೆ."
            ),
            monthPrediction = LocalizedText(
                "New skill acquisitions and academic excellence unlock promising career vistas.",
                "నూతన విషయాలు నేర్చుకుంటారు. విదేశీ లేదా దూరప్రాంత యత్నాలు ఫలిస్తాయి.",
                "ज्ञानार्जन एवं पदोन्नति के योग।",
                "கல்வி மற்றும் திறமைகள் பளிச்சிடும்.",
                "ವಿದ್ಯಾಭ್ಯಾಸದಲ್ಲಿ ಉನ್ನತ ಸಾಧನೆ."
            ),
            remedy = LocalizedText(
                "Chant Sri Venkateswara Ashtottaram or read sacred Bhagavad Gita Chapter 12.",
                "శ్రీ వేంకటేశ్వర అష్టోత్తర శతనామావళి పఠించండి.",
                "भगवद्गीता के 12वें अध्याय का पाठ करें।",
                "பகவத் கீதை 12-ம் அத்தியாயம் வாசிக்கவும்.",
                "ಶ್ರೀ ವೆಂಕಟೇಶ್ವರ ಅಷ್ಟೋತ್ತರ ಪಠಿಸಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.TULA,
            rulingPlanet = LocalizedText("Venus (Shukra)", "శుక్రుడు", "शुक्र", "சுக்கிரன்", "ಶುಕ್ರ"),
            luckyColor = LocalizedText("Sky Blue & Rose", "ఆకాశ నీలం, గులాబీ", "गुलाबी", "ரோஸ்", "ಗುಲಾಬಿ"),
            luckyNumber = "6, 7, 9",
            todayPrediction = LocalizedText(
                "Harmony restored in partnerships. Social connections bring delight and new prospects.",
                "భాగస్వామ్య వ్యాపారాలలో సమన్వయం. మిత్రుల సహకారం లభిస్తుంది.",
                "साझेदारी में लाभ एवं मधुरता।",
                "நண்பர்கள் மூலம் மகிழ்ச்சி உண்டாகும்.",
                "ಸ್ನೇಹಿತರಿಂದ ಉತ್ತಮ ಬೆಂಬಲ."
            ),
            weekPrediction = LocalizedText(
                "Splendid social events and joyous celebrations with near and dear ones.",
                "శుభకార్యాలలో పాల్గొంటారు. వస్త్రాభరణాలు లభించే యోగం.",
                "उत्सवों एवं मंगल कार्यों में भाग लेंगे।",
                "சுப நிகழ்வுகளில் கலந்துகொள்வீர்கள்.",
                "ಶುಭ ಸಮಾರಂಭಗಳಲ್ಲಿ ಭಾಗಿ."
            ),
            monthPrediction = LocalizedText(
                "Balanced income and rewarding leisure endeavors. Marital bliss deepens.",
                "ఆర్థిక సమతుల్యత చేకూరుతుంది. దాంపత్య జీవితం ఆనందదాయకంగా ఉంటుంది.",
                "वैवाहिक जीवन में सुख-समृद्धि।",
                "குடும்ப வாழ்க்கை இனிமையாக அமையும்.",
                "ವೈವಾಹಿಕ ಜೀವನದಲ್ಲಿ ಸಾಮರಸ್ಯ."
            ),
            remedy = LocalizedText(
                "Light sesame oil lamp before Goddess Durga on Friday evening.",
                "శుక్రవారం సాయంత్రం దుర్గాదేవి సన్నిధిలో దీపారాధన చేయండి.",
                "दुर्गा चालीसा का पाठ करें।",
                "துர்க்கை அம்மன் வழிபாடு நலம் தரும்.",
                "ದುರ್ಗಾದೇವಿಗೆ ದೀಪ ಬೆಳಗಿಸಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.VRISCHIKA,
            rulingPlanet = LocalizedText("Mars (Kuja)", "కుజుడు", "मंगल", "செவ்வாய்", "ಕುಜ"),
            luckyColor = LocalizedText("Deep Crimson & Coral", "ముదురు ఎరుపు, పగడపు వర్ణం", "गहरा लाल", "சிவப்பு", "ಕೆಂಪು"),
            luckyNumber = "9, 8, 3",
            todayPrediction = LocalizedText(
                "Determination conquers complex obstacles. Deep insights and research flourish.",
                "మనోధైర్యంతో అడ్డంకులను అధిగమిస్తారు. రహస్య విషయాలపై పట్టు సాధిస్తారు.",
                "कठिन परिस्थितियों पर विजय प्राप्त होगी।",
                "மன தைரியத்துடன் காரியங்களை முடிப்பீர்கள்.",
                "ಆತ್ಮವಿಶ್ವಾಸದಿಂದ ಸವಾಲುಗಳನ್ನು ಎದುರಿಸಿ."
            ),
            weekPrediction = LocalizedText(
                "Financial recoveries and repayment of past debts bring great mental relief.",
                "బాకీలు వసూలవుతాయి. మానసిక ఒత్తిడి తొలగి ఉపశమనం లభిస్తుంది.",
                "रुका हुआ धन वापस मिलने के योग।",
                "பழைய பாக்கிகள் வசூலாகும்.",
                "ಹಳೆಯ ಬಾಕಿಗಳು ವಸೂಲಾಗುತ್ತವೆ."
            ),
            monthPrediction = LocalizedText(
                "Profound spiritual evolution and sudden unexpected gains through legacy or real estate.",
                "ఆధ్యాత్మిక చైతన్యం పెరుగుతుంది. స్థిరాస్తి వ్యవహారాలు కొలిక్కి వస్తాయి.",
                "अध्यात्म एवं अचल संपत्ति में लाभ।",
                "நிலம் மற்றும் ரியல் எஸ்டேட்டில் லாபம்.",
                "ಸ್ಥಿರಾಸ್ತಿ ವ್ಯವಹಾರಗಳಲ್ಲಿ ಜಯ."
            ),
            remedy = LocalizedText(
                "Chant Subrahmanya Bhujangam or offer red kanagale flowers to Lord Kartikeya.",
                "శ్రీ సుబ్రహ్మణ్య స్వామి అష్టకము పఠించండి.",
                "भगवान कार्तिकेय की आराधना करें।",
                "முருகப் பெருமானை வழிபடவும்.",
                "ಸುಬ್ರಹ್ಮಣ್ಯ ಸ್ವಾಮಿಯ ಪೂಜೆ ಮಾಡಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.DHANUSU,
            rulingPlanet = LocalizedText("Jupiter (Brihaspati)", "గురువు", "गुरु", "குரு", "ಗುರು"),
            luckyColor = LocalizedText("Bright Yellow & Gold", "పసుపు, బంగారు వర్ణం", "पीला", "மஞ்சள்", "ಹಳದಿ"),
            luckyNumber = "3, 9, 1",
            todayPrediction = LocalizedText(
                "Philosophical outlook brings serenity. Mentorship from noble elders guides you.",
                "పెద్దల ఆశీస్సులు లభిస్తాయి. ధర్మబద్ధమైన ఆలోచనలతో ముందడుగు వేస్తారు.",
                "गुरुजनों का मार्गदर्शन एवं मानसिक शांति।",
                "பெரியவர்களின் ஆசி கிடைக்கும்.",
                "ಹಿರಿಯರ ಮಾರ್ಗದರ್ಶನ ಮತ್ತು ಆಶೀರ್ವಾದ."
            ),
            weekPrediction = LocalizedText(
                "Expansion of wisdom and spiritual pursuits. Great luck in higher learning and teaching.",
                "విద్యా రంగం వారికి విశేషమైన అనుకూలత. సత్కర్మలు ఆచరిస్తారు.",
                "ज्ञान एवं उच्च शिक्षा में प्रगति।",
                "கல்வியில் மேன்மை உண்டாகும்.",
                "ಉನ್ನತ ಶಿಕ್ಷಣದಲ್ಲಿ ಉತ್ತಮ ಪ್ರಗತಿ."
            ),
            monthPrediction = LocalizedText(
                "High auspiciousness in long-distance travel and temple pilgrimage tours.",
                "పుణ్యకార్యాలు నిర్వహిస్తారు. దూర ప్రయాణాలు శుభప్రదం.",
                "धार्मिक यात्राएं मंगलकारी रहेंगी।",
                "ஆன்மீக யாத்திரைகள் நன்மை தரும்.",
                "ತೀರ್ಥಯಾತ್ರೆಗಳಿಂದ ಶುಭ."
            ),
            remedy = LocalizedText(
                "Chant Guru Paduka Stotram or offer yellow chana dal to Lord Dakshinamurthy.",
                "గురువారం గురు పాదుకా స్తోత్రం పఠించండి, శనగలు సమర్పించండి.",
                "गुरुवार को चने की दाल का दान करें।",
                "தட்சிணாமூர்த்தி வழிபாடு நலம் பயக்கும்.",
                "ದಕ್ಷಿಣಾಮೂರ್ತಿ ಪೂಜೆ ಮಾಡಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.MAKARA,
            rulingPlanet = LocalizedText("Saturn (Shani)", "శని దేవుడు", "शनि", "சனி", "ಶನಿ"),
            luckyColor = LocalizedText("Royal Blue & Charcoal", "నీలం, నలుపు", "नीला", "நீலம்", "ನೀಲಿ"),
            luckyNumber = "8, 4, 6",
            todayPrediction = LocalizedText(
                "Hard work yields tangible fruits. Professional resilience commands respect.",
                "కృషికి తగిన ప్రతిఫలం దక్కుతుంది. వృత్తి బాధ్యతలను సమర్థవంతంగా నిర్వహిస్తారు.",
                "कठिन परिश्रम का उचित फल मिलेगा।",
                "உழைப்புக்கு ஏற்ற பலன் கிடைக்கும்.",
                "ಶ್ರಮಕ್ಕೆ ತಕ್ಕ ಪ್ರತಿಫಲ ದೊರೆಯುತ್ತದೆ."
            ),
            weekPrediction = LocalizedText(
                "Stable progress in long-term career foundations. Patience pays rich rewards.",
                "ఓర్పుతో వ్యవహరించి పనులు సాధిస్తారు. క్రమశిక్షణతో ప్రగతి సాధిస్తారు.",
                "दीर्घकालिक योजनाओं में सफलता।",
                "தொழிலில் பொறுமை வெற்றி தரும்.",
                "ತಾಳ್ಮೆಯಿಂದ ಕೆಲಸಗಳಲ್ಲಿ ಜಯ."
            ),
            monthPrediction = LocalizedText(
                "Constructive developments in home and profession. Steady elevation in status.",
                "సమాజంలో హోదా పెరుగుతుంది. స్థిరమైన ఆర్థికాభివృద్ధి కలుగుతుంది.",
                "कार्यक्षेत्र में पद-प्रतिष्ठा में वृद्धि।",
                "பதவி உயர்வு வாய்ப்பு உண்டு.",
                "ಸಮಾಜದಲ್ಲಿ ಗೌರವ ಹೆಚ್ಚಾಗಲಿದೆ."
            ),
            remedy = LocalizedText(
                "Light sesame oil lamp on Saturday and chant Dasharatha Shani Stotram.",
                "శనివారం నువ్వుల నూనెతో దీపారాధన చేసి దశరథ శని స్తోత్రం పఠించండి.",
                "शनिवार को तिल के तेल का दीपक जलाएं।",
                "சனிக்கிழமை எள் தீபம் ஏற்றி வழிபடவும்.",
                "ಶನಿವಾರ ಎಳ್ಳೆಣ್ಣೆ ದೀಪ ಹಚ್ಚಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.KUMBHA,
            rulingPlanet = LocalizedText("Saturn (Shani)", "శని దేవుడు", "शनि", "சனி", "ಶನಿ"),
            luckyColor = LocalizedText("Electric Blue & Violet", "నీలం, ఊదా", "जामुनी", "ஊதா", "ನೇರಳೆ"),
            luckyNumber = "4, 8, 7",
            todayPrediction = LocalizedText(
                "Innovative ideas gain applause. Community service and humanitarian acts uplift you.",
                "నూతన ఆవిష్కరణలకు ప్రశంసలు. సేవా కార్యక్రమాలలో పాల్గొంటారు.",
                "नवीन विचारों की सराहना होगी।",
                "புதிய சிந்தனைகள் வெற்றி தரும்.",
                "ಹೊಸ ವಿಚಾರಗಳಿಗೆ ಪ್ರಶಂಸೆ."
            ),
            weekPrediction = LocalizedText(
                "Collaboration with visionary friends opens fruitful avenues for wealth creation.",
                "స్నేహితుల సహకారంతో కొత్త ప్రయత్నాలు మొదలుపెడతారు.",
                "मित्रों के सहयोग से लाभ होगा।",
                "நண்பர்களால் நன்மை உண்டாகும்.",
                "ಸ್ನೇಹಿತರ ಸಹಕಾರದಿಂದ ಲಾಭ."
            ),
            monthPrediction = LocalizedText(
                "Widespread positive impact in your chosen domain. Financial clarity shines.",
                "వృత్తి వ్యాపారాలలో విశేషమైన లాభాలు, సమాజ హితం చేకూరుతుంది.",
                "समाज में ख्याति एवं धन लाभ।",
                "சமூகத்தில் புகழ் மற்றும் தன லாபம்.",
                "ವ್ಯಾಪಾರದಲ್ಲಿ ವಿಶೇಷ ಲಾಭ."
            ),
            remedy = LocalizedText(
                "Perform Anna Dhanam (food charity) to the needy or chant Hanuman Ashtak.",
                "పేదలకు అన్నదానం లేదా పండ్ల దానం చేయండి, హనుమాన్ అష్టకం చదవండి.",
                "निर्धनों को अन्न दान करें।",
                "ஏழைகளுக்கு அன்னதானம் செய்யவும்.",
                "ಅನ್ನದಾನ ಅಥವಾ ಹನುಮಾನ್ ಅಷ್ಟಕ ಪಠಿಸಿ."
            )
        ),
        RasiPhalalu(
            sign = ZodiacSign.MEENA,
            rulingPlanet = LocalizedText("Jupiter (Brihaspati)", "గురువు", "गुरु", "குரு", "ಗುರು"),
            luckyColor = LocalizedText("Sea Green & Saffron Gold", "సముద్రపు పచ్చ, పసుపు", "पीला व हरा", "மஞ்சள்", "ಹಳದಿ"),
            luckyNumber = "3, 7, 2",
            todayPrediction = LocalizedText(
                "Spiritual bliss and devotional tranquility. Creative imagination is at its pinnacle.",
                "ఆధ్యాత్మిక శాంతి, కళాత్మక ఆలోచనలతో గడుపుతారు. దైవ కృప పుష్కలంగా ఉంటుంది.",
                "आध्यात्मिक आनंद एवं मानसिक शांति।",
                "மன அமைதியும் இறை அருளும் கிடைக்கும்.",
                "ಆಧ್ಯಾತ್ಮಿಕ ಶಾಂತಿ ಮತ್ತು ನೆಮ್ಮದಿ."
            ),
            weekPrediction = LocalizedText(
                "Auspicious ceremonies in family. Compassionate deeds bring good karma and blessings.",
                "గృహంలో శుభకార్య యోగం. పరోపకార గుణం వల్ల కీర్తి లభిస్తుంది.",
                "परिवार में मांगलिक कार्यों के योग।",
                "குடும்பத்தில் சுப காரியங்கள் நடக்கும்.",
                "ಕುಟುಂಬದಲ್ಲಿ ಶುಭ ಸಮಾರಂಭ."
            ),
            monthPrediction = LocalizedText(
                "Divine protection during all ventures. Favorable outcomes in long-pending dreams.",
                "ఇష్టదేవతా అనుగ్రహం వల్ల అనుకున్న పనులు నిర్విఘ్నంగా పూర్తవుతాయి.",
                "ईश्वर की कृपा से मनोकामनाएं पूर्ण होंगी।",
                "நினைத்த காரியங்கள் தடையின்றி முடியும்.",
                "ಮನೋಕಾಮನೆಗಳು ಈಡೇರುತ್ತವೆ."
            ),
            remedy = LocalizedText(
                "Offer tulasi leaves to Lord Sri Krishna and chant Maha Mantra (Hare Krishna).",
                "శ్రీకృష్ణునికి తులసీ దళాలు సమర్పించండి, హరే కృష్ణ నామస్మరణ చేయండి.",
                "भगवान कृष्ण को तुलसी दल अर्पित करें।",
                "துளசி மாலை சாற்றி வழிபடவும்.",
                "ಶ್ರೀ ಕೃಷ್ಣನಿಗೆ ತುಳಸಿ ಅರ್ಪಿಸಿ."
            )
        )
    )

    fun getAllRasi(): List<RasiPhalalu> = allRasiData

    fun getRasi(sign: ZodiacSign): RasiPhalalu {
        return allRasiData.firstOrNull { it.sign == sign } ?: allRasiData[0]
    }
}
