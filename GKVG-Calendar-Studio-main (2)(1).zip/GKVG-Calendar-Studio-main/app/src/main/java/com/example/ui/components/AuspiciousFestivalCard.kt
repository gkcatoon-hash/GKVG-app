package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.Festival
import com.example.ui.theme.SacredGold300
import com.example.ui.theme.SacredGold500
import com.example.ui.theme.SleekCardSurface
import com.example.ui.theme.SleekNavyBackground
import java.time.format.DateTimeFormatter

@Composable
fun AuspiciousFestivalCard(
    festivals: List<Festival>,
    language: AppLanguage,
    onViewAllClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val topFestival = festivals.firstOrNull()

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = SacredGold500
        ),
        border = BorderStroke(1.dp, SacredGold300),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onViewAllClick() }
            .testTag("festival_highlight_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TODAY'S FESTIVAL",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SleekNavyBackground.copy(alpha = 0.85f),
                    letterSpacing = 2.sp
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SleekNavyBackground.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = topFestival?.date?.format(DateTimeFormatter.ofPattern("MMM dd")) ?: "Auspicious Day",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SleekNavyBackground,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (topFestival != null) {
                Text(
                    text = topFestival.name.get(language),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = SleekNavyBackground,
                    lineHeight = 24.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = topFestival.description.get(language),
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = SleekNavyBackground.copy(alpha = 0.85f),
                    maxLines = 2
                )
            } else {
                Text(
                    text = "Nitya Puja & Auspicious Day",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = SleekNavyBackground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "No major festival for today. Perform regular daily devotional archana.",
                    fontSize = 12.sp,
                    color = SleekNavyBackground.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Deity: ${topFestival?.deityAssociated ?: "Lord Maha Vishnu"}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SleekNavyBackground.copy(alpha = 0.85f)
                )

                Text(
                    text = "View Calendar Festivals →",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SleekNavyBackground,
                    modifier = Modifier.testTag("festivals_view_all_button")
                )
            }
        }
    }
}

