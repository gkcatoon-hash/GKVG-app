package com.example.data.model

enum class AppLanguage(val code: String, val nativeName: String, val englishName: String) {
    ENGLISH("en", "English", "English"),
    TELUGU("te", "తెలుగు", "Telugu"),
    HINDI("hi", "हिन्दी", "Hindi"),
    TAMIL("ta", "தமிழ்", "Tamil"),
    KANNADA("kn", "ಕನ್ನಡ", "Kannada")
}

data class LocalizedText(
    val en: String,
    val te: String = en,
    val hi: String = en,
    val ta: String = en,
    val kn: String = en
) {
    fun get(language: AppLanguage): String {
        return when (language) {
            AppLanguage.ENGLISH -> en
            AppLanguage.TELUGU -> te
            AppLanguage.HINDI -> hi
            AppLanguage.TAMIL -> ta
            AppLanguage.KANNADA -> kn
        }
    }
}
