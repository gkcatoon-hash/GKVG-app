package com.example.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.ui.theme.SacredGold300
import com.example.ui.theme.SacredGold400
import com.example.ui.theme.SacredGold500
import com.example.ui.theme.SleekNavyBackground
import com.example.ui.theme.SleekObsidianNav
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    language: AppLanguage,
    onSplashFinished: () -> Unit
) {
    val scale = remember { Animatable(0.78f) }
    val alpha = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }

    // Breathing glow animation
    val infiniteTransition = rememberInfiniteTransition(label = "SplashAura")
    val auraScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AuraGlow"
    )

    val flameAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "FlameGlow"
    )

    LaunchedEffect(Unit) {
        alpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(700, easing = FastOutSlowInEasing)
        )
        scale.animateTo(
            targetValue = 1f,
            animationSpec = tween(700, easing = FastOutSlowInEasing)
        )
        textAlpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(600, easing = FastOutSlowInEasing)
        )
        delay(1800)
        onSplashFinished()
    }

    val subtitle = when (language) {
        AppLanguage.TELUGU -> "మీ నిత్య దైవ పంచాంగ దర్శిని"
        AppLanguage.HINDI -> "आपका दैनिक भक्ति पंचांग"
        AppLanguage.TAMIL -> "உங்கள் தினசரி ஆன்மீக பஞ்சாங்கம்"
        AppLanguage.KANNADA -> "ನಿಮ್ಮ ನಿತ್ಯ ಭಕ್ತಿ ಪಂಚಾಂಗ"
        AppLanguage.ENGLISH -> "Your Daily Devotional Companion"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        SleekNavyBackground,
                        SleekObsidianNav,
                        Color(0xFF000814)
                    ),
                    radius = 1200f
                )
            )
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                onSplashFinished()
            }
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("gkvg_splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Central Emblem & Typography
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 32.dp)
        ) {
            // Golden Breathing Aura Halo behind Logo
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(190.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(175.dp)
                        .scale(auraScale)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    SacredGold500.copy(alpha = 0.22f),
                                    SacredGold500.copy(alpha = 0.05f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Master GKVG Vector Logo
                Image(
                    painter = painterResource(id = R.drawable.ic_gkvg_logo),
                    contentDescription = "GKVG Official Logo",
                    modifier = Modifier
                        .size(150.dp)
                        .scale(scale.value)
                        .alpha(alpha.value)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Main Brand Title
            Text(
                text = "GKVG CALENDAR",
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                color = SacredGold400,
                letterSpacing = 3.sp,
                modifier = Modifier
                    .alpha(textAlpha.value)
                    .testTag("splash_app_title")
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Your Daily Devotional Companion",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = SacredGold300.copy(alpha = 0.9f),
                letterSpacing = 1.2.sp,
                modifier = Modifier.alpha(textAlpha.value)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Sacred Telugu Devotional Tagline
            Text(
                text = "భక్తి • పంచాంగం • సంప్రదాయం",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.95f),
                textAlign = TextAlign.Center,
                letterSpacing = 0.8.sp,
                modifier = Modifier.alpha(textAlpha.value)
            )
        }

        // Bottom Diya & Auspicious Footer
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 36.dp)
                .alpha(textAlpha.value)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_gkvg_diya),
                    contentDescription = "Sacred Diya",
                    modifier = Modifier
                        .size(32.dp)
                        .alpha(flameAlpha)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "శుభం భవతు • సర్వే జనాః సుఖినో భవంతు",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SacredGold500
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "v1.0.0 • Offline Ready Panchang",
                fontSize = 10.sp,
                color = Color.White.copy(alpha = 0.45f)
            )
        }
    }
}
