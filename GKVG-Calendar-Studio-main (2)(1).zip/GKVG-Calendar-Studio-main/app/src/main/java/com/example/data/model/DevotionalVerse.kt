package com.example.data.model

data class DevotionalVerse(
    val id: String,
    val title: LocalizedText,
    val slokaOriginal: String,
    val transliteration: String,
    val meaning: LocalizedText,
    val source: LocalizedText,
    val deity: String
)
