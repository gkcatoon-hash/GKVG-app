package com.example.data.model

data class PanchangLocation(
    val id: String,
    val cityName: String,
    val stateOrCountry: String,
    val latitude: Double,
    val longitude: Double,
    val timezone: String
)

val StandardLocations = listOf(
    PanchangLocation("hyd", "Hyderabad", "Telangana, India", 17.3850, 78.4867, "IST (+5:30)"),
    PanchangLocation("vij", "Vijayawada", "Andhra Pradesh, India", 16.5062, 80.6480, "IST (+5:30)"),
    PanchangLocation("tpt", "Tirupati", "Andhra Pradesh, India", 13.6288, 79.4192, "IST (+5:30)"),
    PanchangLocation("vzg", "Visakhapatnam", "Andhra Pradesh, India", 17.6868, 83.2185, "IST (+5:30)"),
    PanchangLocation("blr", "Bengaluru", "Karnataka, India", 12.9716, 77.5946, "IST (+5:30)"),
    PanchangLocation("chn", "Chennai", "Tamil Nadu, India", 13.0827, 80.2707, "IST (+5:30)"),
    PanchangLocation("mum", "Mumbai", "Maharashtra, India", 19.0760, 72.8777, "IST (+5:30)"),
    PanchangLocation("del", "New Delhi", "Delhi, India", 28.6139, 77.2090, "IST (+5:30)"),
    PanchangLocation("lon", "London", "United Kingdom", 51.5074, -0.1278, "GMT (+0:00)"),
    PanchangLocation("sfo", "San Jose / Bay Area", "California, USA", 37.3382, -121.8863, "PST (-8:00)")
)
